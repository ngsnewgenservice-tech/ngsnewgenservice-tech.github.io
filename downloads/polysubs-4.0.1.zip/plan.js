/* Free / Premium limits and store settings. Shared by background, content scripts and popup. */
const PS_CONFIG = {
  // Lemon Squeezy checkout link for Premium (fill in after creating the product).
  // The monthly plan has a 1-month free trial set in Lemon Squeezy.
  checkoutUrl: "https://polysubs.lemonsqueezy.com/checkout/buy/396fafd6-6031-44a6-9484-0debd2e46764",
  // Lemon Squeezy IDs used to reject license keys from other stores/products. 0 = don't check.
  storeId: 516053,
  productId: 1504061,
  website: "https://ngsnewgenservice-tech.github.io",
  // Re-check the license with Lemon Squeezy this often, and keep Premium working offline for this long.
  revalidateMs: 3 * 24 * 3600 * 1000,
  graceMs: 14 * 24 * 3600 * 1000
};

const PS_QUIZ_TYPES = ["mcq", "reverse", "blank", "listen", "order", "speak"];

const PS_LIMITS = {
  free: { maxLangs: 2, quizMax: 5, types: ["mcq", "reverse"], maxWords: 50 },
  pro:  { maxLangs: 8, quizMax: 30, types: PS_QUIZ_TYPES, maxWords: Infinity }
};

/* license: the object stored in chrome.storage.local under "license". */
function psIsPro(license) {
  if (!license || license.status !== "active") return false;
  return Date.now() - (license.validatedAt || 0) < PS_CONFIG.graceMs;
}
function psLimits(license) { return psIsPro(license) ? PS_LIMITS.pro : PS_LIMITS.free; }
