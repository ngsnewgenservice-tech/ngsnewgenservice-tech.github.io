# PolySubs 4.0 – Multilingual Subtitles & Language Learning

Chrome extension (Manifest V3) that shows YouTube subtitles in several languages at once and helps people learn them.

## What's new in 4.0
- **Video quiz** — offered automatically when a video ends, or anytime from the 🎯 button on the player (shortcut: `G`).
  Question types: word → meaning, meaning → word, fill in the blank, listening (replays the real clip), sentence order, speaking.
  The learner picks which of their translation languages to be tested in (one or several), how many questions (default 10)
  and where the quiz appears (on the video or in a side panel).
- **Speaking practice** in a small extension window, so Chrome's microphone prompt names PolySubs, not youtube.com.
- **Progress per word and per language** (`progress` in local storage, spaced-repetition boxes 0–5) and quiz history (`quizHistory`).
  Every record has an `id` and `updatedAt` so it can be synced to a web app later.
- **Interface in 10 languages** (en, ar, es, fr, pt, zh, hi, ru, id, de), chosen in the popup. Arabic switches to right-to-left.
- **Free / Premium** with Lemon Squeezy license keys (no server needed).
- **YouTube auto-translation fallback** when Google translation fails or is rate-limited.
- YouTube page selectors are grouped in `SEL` at the top of `content.js`.

## Free vs Premium (edit in `plan.js`)
| | Free | Premium |
|---|---|---|
| Translation languages | 2 | 8 |
| Questions per quiz | 5 | 30 |
| Question types | word → meaning, meaning → word | all 6 |
| Saved words | 50 | unlimited |

## Test it locally
1. Open `chrome://extensions`, turn on **Developer mode**.
2. Click **Load unpacked** and choose this folder.
3. Open a YouTube video that has subtitles.

## Before publishing: connect Lemon Squeezy
In `plan.js` → `PS_CONFIG`:
- `checkoutUrl`: your Premium checkout link. The monthly plan has a 1-month free trial (set in Lemon Squeezy).
- `storeId`, `productId`: your Lemon Squeezy IDs, so keys from other products are rejected.

In Lemon Squeezy, turn on **license keys** for the Premium product and set the activation limit (for example 3 devices).

## Files
- `content.js` — subtitles box, word lookup, read-aloud (existing features)
- `quiz.js` / `quiz.css` — the video quiz
- `speak.html` / `speak.js` — speaking window
- `background.js` — translation, cache, license checks
- `i18n.js` — interface text in 10 languages
- `plan.js` — Free/Premium limits and store settings
