importScripts("plan.js");

/* ===== خدمة الترجمة: طابور محدود + ذاكرة دائمة + Google / نموذج لغوي ===== */
const LANG_NAMES = { ar: "Arabic", en: "English", fr: "French", es: "Spanish", de: "German", it: "Italian",
  pt: "Portuguese", ru: "Russian", tr: "Turkish", nl: "Dutch", ja: "Japanese", ko: "Korean",
  "zh-CN": "Simplified Chinese", hi: "Hindi" };
const nameOf = (c) => LANG_NAMES[c] || LANG_NAMES[(c || "").split("-")[0]] || c;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const isLLM = (cfg) => cfg.provider === "claude" || cfg.provider === "openai";

async function getCfg() {
  const s = await chrome.storage.sync.get({ provider: "google", dialect: "msa", llmBase: "https://api.openai.com/v1",
                                            models: { claude: "claude-haiku-5-5", openai: "" } });
  const l = await chrome.storage.local.get({ llmKey: "" });
  return Object.assign({}, s, { llmKey: l.llmKey });
}

/* ---- ذاكرة دائمة (LRU) على جهاز المستخدم ---- */
const CACHE_MAX = 4000;
let cache = new Map(), cacheReady = null, saveT = null;
function loadCache() {
  if (!cacheReady) cacheReady = chrome.storage.local.get({ trcache: [] }).then(({ trcache }) => { cache = new Map(trcache); });
  return cacheReady;
}
function cacheGet(k) {
  if (!cache.has(k)) return undefined;
  const v = cache.get(k); cache.delete(k); cache.set(k, v);
  return v;
}
function cacheSet(k, v) {
  cache.set(k, v);
  while (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value);
  clearTimeout(saveT);
  saveT = setTimeout(() => chrome.storage.local.set({ trcache: [...cache] }), 4000);
}

/* ---- Google (غير رسمي): طابور بحد للطلبات + انتظار عند 429 ---- */
class RateLimitError extends Error {
  constructor(secs) { super("Google أوقف الطلبات مؤقتاً — حاول بعد " + secs + " ثانية"); this.secs = secs; }
}
const G = { blockedUntil: 0, backoff: 30000, last: 0 };
const G_INTERVAL = 350;                                  // ≈ 3 طلبات في الثانية كحد أقصى
const GQ = [];
let pumping = false;
const blockedSecs = () => Math.max(0, Math.ceil((G.blockedUntil - Date.now()) / 1000));

function gEnqueue(url, urgent) {
  return new Promise((resolve, reject) => {
    const item = { url, resolve, reject };
    urgent ? GQ.unshift(item) : GQ.push(item);            // نقرات الكلمات لها الأولوية
    pump();
  });
}
async function pump() {
  if (pumping) return;
  pumping = true;
  try {
    while (GQ.length) {
      const item = GQ.shift();
      if (blockedSecs() > 0) { item.reject(new RateLimitError(blockedSecs())); continue; }   // لا نزيد الحظر
      const wait = G.last + G_INTERVAL - Date.now();
      if (wait > 0) await sleep(wait);
      G.last = Date.now();
      try {
        const r = await fetch(item.url);
        if (r.status === 429) {
          G.blockedUntil = Date.now() + G.backoff;
          G.backoff = Math.min(G.backoff * 2, 600000);   // 30ث ثم 60ث ... حتى 10 دقائق
          item.reject(new RateLimitError(blockedSecs()));
          continue;
        }
        if (!r.ok) { item.reject(new Error("Google HTTP " + r.status)); continue; }
        G.backoff = 30000;
        item.resolve(await r.json());
      } catch (e) { item.reject(e); }
    }
  } finally { pumping = false; }
}

async function gtx(text, to, urgent) {
  await loadCache();
  const k = "g|" + to + "|" + text;
  const hit = cacheGet(k);
  if (hit !== undefined) return hit;
  const d = await gEnqueue("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&dt=t&tl=" +
    encodeURIComponent(to) + "&q=" + encodeURIComponent(text), urgent);
  const out = d[0].map((x) => x[0]).join("");
  if (out) cacheSet(k, out);
  return out;
}
async function gtxRich(word, to) {
  await loadCache();
  const k = "w|" + to + "|" + word.toLowerCase();
  const hit = cacheGet(k);
  if (hit !== undefined) return hit;
  const d = await gEnqueue("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&dt=t&dt=bd&tl=" +
    encodeURIComponent(to) + "&q=" + encodeURIComponent(word), true);
  const main = d[0].map((x) => x[0]).join("");
  let alts = [], pos = "";
  if (Array.isArray(d[1]) && d[1][0]) {
    pos = d[1][0][0] || "";
    alts = (d[1][0][1] || []).filter((a) => a && a !== main).slice(0, 5);
  }
  const out = { main, alts, pos, note: "" };
  if (main) cacheSet(k, out);
  return out;
}

/* ---- نموذج لغوي ---- */
async function callLLM(cfg, system, user, maxTokens) {
  if (!cfg.llmKey) throw new Error("لا يوجد مفتاح API في الإعدادات");
  if (cfg.provider === "claude") {
    const model = (cfg.models && cfg.models.claude) || "claude-haiku-5-5";
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": cfg.llmKey, "anthropic-version": "2023-06-01",
                 "anthropic-dangerous-direct-browser-access": "true" },
      body: JSON.stringify({ model, max_tokens: maxTokens || 2000, system, messages: [{ role: "user", content: user }] })
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && j.error.message) || "Claude HTTP " + r.status);
    return (j.content || []).map((b) => b.text || "").join("");
  }
  const base = (cfg.llmBase || "https://api.openai.com/v1").replace(/\/+$/, "");
  const model = cfg.models && cfg.models.openai;
  if (!model) throw new Error("اكتب اسم النموذج في الإعدادات");
  const r = await fetch(base + "/chat/completions", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer " + cfg.llmKey },
    body: JSON.stringify({ model, temperature: 0.3,
      messages: [{ role: "system", content: system }, { role: "user", content: user }] })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j.error && (j.error.message || j.error)) || "HTTP " + r.status);
  return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || "";
}

function arabicStyle(to, dialect) {
  if (to !== "ar") return "";
  return dialect === "darija"
    ? " Write in Moroccan Arabic (Darija) using Arabic script, as Moroccans actually speak: natural, colloquial, easy to understand."
    : " Write in clear, natural, conversational Modern Standard Arabic. It must not sound stiff, literal, or machine-translated.";
}
function batchSystem(to, src, dialect) {
  return `You are an expert subtitle translator and interpreter. Translate subtitle sentences from ${nameOf(src)} to ${nameOf(to)}.${arabicStyle(to, dialect)}
Rules:
- Translate the meaning and tone the way a native speaker would say it. Never translate word-for-word.
- Each input line is one complete spoken sentence. Return exactly the same number of lines.
- "context" lines are for understanding only. Do NOT translate them.
- Never output sound descriptions, symbols in brackets, music notes or emojis. If a line has only such cues, return an empty string for it.
- Keep names, brands and numbers correct. Use natural punctuation (commas and full stops) so the text can be read aloud with natural pauses.
- Output ONLY a JSON array of strings. No commentary.`;
}
const parseJson = (txt, re) => JSON.parse((txt.match(re) || [""])[0]);

async function llmBatch(cfg, msg) {
  const out = await callLLM(cfg, batchSystem(msg.to, msg.src, cfg.dialect),
    JSON.stringify({ context: msg.context || [], lines: msg.texts }), 3000);
  const arr = parseJson(out, /\[[\s\S]*\]/);
  if (!Array.isArray(arr) || arr.length !== msg.texts.length) throw new Error("رد غير متوقع من النموذج");
  return arr.map((x) => String(x == null ? "" : x));
}

const HANDLERS = {
  async translateBatch(msg) {
    await loadCache();
    const cfg = await getCfg();
    const pre = "l|" + cfg.provider + "|" + cfg.dialect + "|" + msg.to + "|";
    const texts = msg.texts.map(() => "");
    let reason = "", rateLimited = 0;

    if (isLLM(cfg)) {
      const missing = [];
      msg.texts.forEach((t, i) => { const h = cacheGet(pre + t); if (h !== undefined) texts[i] = h; else missing.push(i); });
      if (!missing.length) return { texts, provider: cfg.provider };
      try {
        const arr = await llmBatch(cfg, Object.assign({}, msg, { texts: missing.map((i) => msg.texts[i]) }));
        missing.forEach((i, j) => { texts[i] = arr[j]; if (arr[j]) cacheSet(pre + msg.texts[i], arr[j]); });
        return { texts, provider: cfg.provider };
      } catch (e) { reason = e.message; }
    }
    // Google (الأساسي أو الاحتياطي عند فشل النموذج)
    for (let i = 0; i < msg.texts.length; i++) {
      if (texts[i]) continue;
      try { texts[i] = await gtx(msg.texts[i], msg.to, false); }
      catch (e) {
        reason = reason || e.message;
        if (e instanceof RateLimitError) { rateLimited = e.secs; break; }
      }
    }
    return { texts, provider: "google", fallbackReason: reason, rateLimited };
  },
  async translate(msg) {
    if (msg.useProvider) {
      const r = await HANDLERS.translateBatch({ texts: [msg.text], to: msg.to, src: msg.src, context: [] });
      return { text: r.texts[0] || "", fallbackReason: r.fallbackReason, rateLimited: r.rateLimited };
    }
    try { return { text: await gtx(msg.text, msg.to, !!msg.urgent) }; }
    catch (e) { return { text: "", error: e.message, rateLimited: e instanceof RateLimitError ? e.secs : 0 }; }
  },
  async lookup(msg) {
    const cfg = await getCfg();
    if (isLLM(cfg)) {
      try {
        const sys = `You are a precise bilingual dictionary.${arabicStyle(msg.to, cfg.dialect)} The user gives a word taken from a sentence and a target language. Reply ONLY with JSON: {"translation":"<best translation of the word in THIS sentence>","alternatives":["<up to 3 other common meanings>"],"note":"<very short usage note in ${nameOf(msg.to)}, optional>"}`;
        const out = await callLLM(cfg, sys, JSON.stringify({ word: msg.word, sentence: msg.sentence || "", target: nameOf(msg.to) }), 600);
        const j = parseJson(out, /\{[\s\S]*\}/);
        if (j.translation) return { main: j.translation, alts: (j.alternatives || []).slice(0, 4), note: j.note || "" };
      } catch (e) { /* نرجع لـ Google */ }
    }
    try { return await gtxRich(msg.word, msg.to); }
    catch (e) { return { error: e.message, rateLimited: e instanceof RateLimitError ? e.secs : 0 }; }
  },
  async status() { return { blocked: blockedSecs(), queued: GQ.length }; },
  async test() {
    const cfg = await getCfg();
    const res = { provider: cfg.provider, blocked: blockedSecs() };
    let t0 = Date.now();
    try { res.google = { ok: true, text: await gtx("Hello, how are you today?", "ar", true), ms: Date.now() - t0 }; }
    catch (e) { res.google = { ok: false, error: e.message }; }
    if (isLLM(cfg)) {
      t0 = Date.now();
      try {
        const arr = await llmBatch(cfg, { texts: ["Hello, how are you today?"], to: "ar", src: "en", context: [] });
        res.llm = { ok: !!arr[0], text: arr[0], ms: Date.now() - t0 };
      } catch (e) { res.llm = { ok: false, error: e.message }; }
    }
    res.blocked = blockedSecs();
    return res;
  }
};

/* ===================== Premium license (Lemon Squeezy) ===================== */
async function lsCall(path, params) {
  const r = await fetch("https://api.lemonsqueezy.com/v1/licenses/" + path, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(params).toString()
  });
  return r.json().catch(() => ({ error: "HTTP " + r.status }));
}
function productMatches(meta) {
  if (!meta) return true;
  if (PS_CONFIG.storeId && meta.store_id !== PS_CONFIG.storeId) return false;
  if (PS_CONFIG.productId && meta.product_id !== PS_CONFIG.productId) return false;
  return true;
}
/* Keys bought with Lemon Squeezy's fake test cards must not unlock Premium in public builds. */
const isTestKey = (j) => !PS_CONFIG.allowTestKeys && !!(j && j.license_key && j.license_key.test_mode);
const getLicense = async () => (await chrome.storage.local.get({ license: null })).license;
const setLicense = (license) => chrome.storage.local.set({ license });

async function validateLicense(force) {
  const lic = await getLicense();
  if (!lic || !lic.key || !lic.instanceId) return lic;
  if (!force && Date.now() - (lic.checkedAt || 0) < PS_CONFIG.revalidateMs) return lic;
  let j;
  try { j = await lsCall("validate", { license_key: lic.key, instance_id: lic.instanceId }); }
  catch (_) { return lic; }                       // offline: keep the last known state (grace period applies)
  const st = j.license_key && j.license_key.status;
  const ok = j.valid === true && st === "active" && productMatches(j.meta) && !isTestKey(j);
  const next = Object.assign({}, lic, { checkedAt: Date.now(), status: ok ? "active" : (st || "invalid") });
  if (ok) next.validatedAt = Date.now();
  await setLicense(next);
  return next;
}

chrome.alarms.create("ps-license", { periodInMinutes: 24 * 60 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "ps-license") validateLicense(false); });
chrome.runtime.onStartup.addListener(() => validateLicense(false));

Object.assign(HANDLERS, {
  async licenseActivate(msg) {
    const key = String(msg.key || "").trim();
    if (!key) return { ok: false, reason: "invalid" };
    let j;
    try { j = await lsCall("activate", { license_key: key, instance_name: "PolySubs on " + (msg.device || "Chrome") }); }
    catch (_) { return { ok: false, reason: "net" }; }
    if (!j.activated) {
      const st = j.license_key && j.license_key.status;
      return { ok: false, reason: st === "expired" || st === "disabled" ? "inactive" : "invalid", detail: j.error || "" };
    }
    if (!productMatches(j.meta) || isTestKey(j)) {
      lsCall("deactivate", { license_key: key, instance_id: j.instance.id }).catch(() => {});
      return { ok: false, reason: "wrong_product" };
    }
    const license = { key, instanceId: j.instance.id, status: "active", validatedAt: Date.now(), checkedAt: Date.now(),
                      email: (j.meta && j.meta.customer_email) || "", plan: (j.meta && j.meta.variant_name) || "" };
    await setLicense(license);
    return { ok: true, license };
  },
  async licenseDeactivate() {
    const lic = await getLicense();
    if (lic && lic.key && lic.instanceId) {
      try { await lsCall("deactivate", { license_key: lic.key, instance_id: lic.instanceId }); } catch (_) {}
    }
    await setLicense(null);
    return { ok: true };
  },
  async licenseValidate(msg) { return { license: await validateLicense(!!msg.force) }; },

  /* Speaking practice runs in a small extension window so the microphone prompt shows the extension, not youtube.com. */
  async openSpeak(msg, sender) {
    const q = new URLSearchParams({ text: msg.text || "", lang: msg.lang || "en", ui: msg.ui || "en",
                                    tab: String(sender.tab ? sender.tab.id : ""), req: String(msg.req || "") });
    await chrome.windows.create({ url: chrome.runtime.getURL("speak.html?" + q.toString()), type: "popup", width: 440, height: 420, focused: true });
    return { ok: true };
  },
  async speakResult(msg) {
    const tabId = Number(msg.tab);
    if (tabId) chrome.tabs.sendMessage(tabId, { type: "speakResult", req: msg.req, transcript: msg.transcript || "", score: msg.score, error: msg.error || "" });
    return { ok: true };
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const h = msg && HANDLERS[msg.type];
  if (!h) return;
  h(msg, sender).then(sendResponse).catch((e) => sendResponse({ error: String((e && e.message) || e) }));
  return true;
});
