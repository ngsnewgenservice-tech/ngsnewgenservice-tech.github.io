/* ===================== Settings ===================== */
/* YouTube page selectors live in one place so a YouTube redesign means a one-line fix. */
const SEL = {
  player: "movie_player",                       // element id
  mainVideo: "video.html5-main-video",
  anyVideo: "video",
  captionSegment: ".ytp-caption-segment",
  adClass: "ad-showing"                          // class on the player while an ad plays
};
const DEFAULT_KEYS = {
  prev: "KeyA", next: "KeyD", repeat: "KeyS", loop: "KeyR", speak: "KeyW",
  save: "KeyB", hideTrans: "KeyH", original: "KeyO", quiz: "KeyQ", autoPause: "KeyP", quizNow: "KeyG"
};
const DEFAULTS = {
  enabled: true, showOriginal: true, hideTrans: false, quiz: false,
  origSize: 22, origColor: "#ffffff",
  bgOpacity: 0.6, width: 70, autoShrink: true, autoScale: true,
  font: "system", weight: 600,
  pos: null,
  autoPause: false, pauseOnLookup: true,
  autoRead: "off", ttsMode: "smart", ttsRate: 1, duck: true,
  shortcuts: true, keys: DEFAULT_KEYS,
  autoPunct: true, pauseScale: 1, voices: {}, origLang: "en",
  smartTr: true, provider: "google", dialect: "msa",
  langs: [{ code: "ar", size: 22, color: "#ffd54a" }],
  uiLang: "", quizAuto: true, quizButton: true, quizCount: 10, quizPlace: "overlay",
  quizLangs: [], quizTypes: ["mcq", "reverse", "blank", "listen", "order", "speak"]
};
const FONTS = {
  system: '"Inter","SF Pro Text","Segoe UI",system-ui,Tahoma,sans-serif',
  serif: 'Georgia,"Times New Roman","Noto Naskh Arabic",serif',
  rounded: '"Nunito","Varela Round","Segoe UI",system-ui,sans-serif',
  mono: 'ui-monospace,"SF Mono",Consolas,monospace'
};

let settings = JSON.parse(JSON.stringify(DEFAULTS));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const ytCode = (c) => (c === "zh-CN" ? "zh-Hans" : c);
const curVideoId = () => new URLSearchParams(location.search).get("v");
const getVideo = () => document.querySelector(SEL.mainVideo) || document.querySelector(SEL.anyVideo);
const T = (k, v) => psT(psUiLang(settings.uiLang), k, v);

/* Premium state (kept in sync with storage) */
let license = null;
const limits = () => psLimits(license);
const activeLangs = () => settings.langs.slice(0, limits().maxLangs);
chrome.storage.local.get({ license: null }, (r) => { license = r.license; });

function syncKeys() {
  const codes = settings.enabled && settings.shortcuts ? Object.values(settings.keys).filter(Boolean) : [];
  window.postMessage({ source: "dsub-cmd", type: "keys", codes }, "*");
}
function loadSettings(cb) {
  chrome.storage.sync.get(DEFAULTS, (s) => {
    settings = s;
    settings.keys = Object.assign({}, DEFAULT_KEYS, s.keys || {});
    syncKeys();
    cb && cb();
  });
}
chrome.storage.onChanged.addListener((c, area) => {
  if (area === "sync") loadSettings(applyStyle);
  if (area === "local" && c.license) license = c.license.newValue || null;
});

/* ===================== الحالة ===================== */
let player = null, box = null, linesEl = null, toastEl = null, prepEl = null, lookupEl = null;
let lineKey = "", dragged = false;
let baseUrl = null, srcKey = null;
let tracks = {};
const trackCache = new Map();
const fb = new Map();
const prepMap = new Map();           // تحميل مسبق للترجمة الاحتياطية
let ccTries = 0, lastTry = 0;
const MAX_TRIES = 6;
let prevT = 0, lastReadKey = "";
let loopChunk = null, pausedChunk = null, pausedByUs = false;
let curOrigChunk = null, curLines = [];
let domMode = false, domText = "", domSince = 0;
const srcLang = () => (srcKey ? srcKey.split("|")[1] : "") || "en";

/* ===================== التقاط رابط الترجمة ===================== */
window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data) return;
  if (e.data.source === "dsub-key") {
    const act = Object.keys(settings.keys).find((a) => settings.keys[a] === e.data.code);
    if (act && ACTIONS[act]) ACTIONS[act]();
    return;
  }
  if (e.data.source !== "dsub") return;
  let u;
  try { u = new URL(e.data.url); } catch (_) { return; }
  const v = u.searchParams.get("v");
  if (!v || v !== curVideoId()) return;
  const key = [v, u.searchParams.get("lang") || "", u.searchParams.get("kind") || ""].join("|");
  baseUrl = u.href;
  if (key !== srcKey) {
    srcKey = key;
    tracks = trackCache.get(key) || {};
    trackCache.set(key, tracks);
    if (trackCache.size > 20) { for (const k of trackCache.keys()) { if (k !== key) { trackCache.delete(k); break; } } }
  }
});

/* ===================== تحليل الترجمة ===================== */
/* ---- حذف ما لا يُترجَم ولا يُقرأ: [موسيقى] [تصفيق] (يضحك) ♪ >> ---- */
function cleanCue(t) {
  return t
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\{[^}]*\}/g, " ")
    .replace(/\(([^()]{1,30})\)/g, (m, inner) => {
      const x = inner.trim();
      return x.split(/\s+/).length <= 3 && x === x.toLowerCase() ? " " : m;   // (laughs) (music) — لا نحذف الجمل الحقيقية
    })
    .replace(/\*[^*]{1,30}\*/g, " ")
    .replace(/[♪♫♬♩🎵🎶]+/g, " ")
    .replace(/^\s*(?:>>+|-\s)\s*/, "")
    .replace(/\s>>+\s/g, " ")
    .replace(/\s+([,.;:!?؟،؛])/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}
function sanitizeForSpeech(t) {
  return cleanCue(t)
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/\p{Extended_Pictographic}/gu, " ")
    .replace(/[*_#~^|\\<>=+]+/g, " ")
    .replace(/\s+/g, " ").trim();
}

/* ---- دمج أسطر الترجمة اليدوية في جمل كاملة مفهومة ---- */
function mergeSentences(chunks) {
  const out = [];
  let cur = null;
  const MAXC = 240, MAXDUR = 14000, GAP = 1500;
  for (const c of chunks) {
    if (cur && (c.start - cur.end > GAP || TERM_RE.test(cur.text) ||
        cur.text.length + c.text.length > MAXC || c.end - cur.start > MAXDUR ||
        (cur.text.length > 120 && /^\p{Lu}/u.test(c.text)))) { out.push(cur); cur = null; }
    if (cur) { cur.text += " " + c.text; cur.end = c.end; } else cur = { start: c.start, end: c.end, text: c.text };
  }
  if (cur) out.push(cur);
  return out;
}

/* توقف المتحدث: نقدّر مدة نطق الكلمة ونطرحها من الفاصل بين بداية كلمتين */
const HARD_SIL = 500, SOFT_SIL = 180, MAX_WORDS = 22;
const wordDur = (w) => Math.min(900, w.length * 65 + 120);
const TERM_RE = /[.!?؟。！？]$/, SOFTP_RE = /[,;:،؛]$/;

function buildAsrChunks(words, punct) {
  words.forEach((x, i) => { x.sil = i ? Math.max(0, x.t - words[i - 1].t - wordDur(words[i - 1].w)) : 99999; });
  const chunks = [];
  let cur = [], capNext = true;
  const flush = (mark) => {                       // mark: "." أو "," أو ""
    if (!cur.length) return;
    let text = cur.map((x, i) => {
      let w = x.w;
      const nxt = cur[i + 1];
      // فاصلة داخل الجملة عند وقفة قصيرة (وليس في أول الجملة ولا آخرها)
      if (punct && nxt && nxt.sil >= SOFT_SIL && i >= 2 && cur.length - i - 1 >= 2 && !TERM_RE.test(w) && !SOFTP_RE.test(w)) w += ",";
      return w;
    }).join(" ");
    if (punct) {
      if (mark && !TERM_RE.test(text) && !SOFTP_RE.test(text)) text += mark;
      if (capNext) text = text.charAt(0).toUpperCase() + text.slice(1);
    }
    const last = cur[cur.length - 1];
    chunks.push({ start: cur[0].t, end: last.t + wordDur(last.w) + 400, text });
    capNext = TERM_RE.test(text);
    cur = [];
  };
  for (const x of words) {
    if (cur.length && x.sil >= HARD_SIL) flush(".");        // وقفة طويلة = نهاية جملة
    cur.push(x);
    if (TERM_RE.test(x.w)) flush("");                       // الترقيم موجود أصلاً
    else if (cur.length >= MAX_WORDS) {                     // جملة طويلة جداً: اقطع عند أكبر وقفة
      let bi = -1, bs = -1;
      for (let j = 5; j < cur.length - 2; j++) if (cur[j].sil > bs) { bs = cur[j].sil; bi = j; }
      if (bi > 0) { const rest = cur.splice(bi); flush(","); cur = rest; } else flush(",");
    }
  }
  flush(".");
  for (let i = 0; i < chunks.length - 1; i++) chunks[i].end = Math.min(chunks[i].end, chunks[i + 1].start);
  return chunks;
}

function parseTrack(data, opts = {}) {
  const punct = opts.punct !== false;
  const events = (data.events || []).filter((e) => e.segs && e.segs.length);
  const hasOffsets = events.some((e) => e.segs.some((x) => x.tOffsetMs != null));
  const clean = (x) => x.replace(/\s+/g, " ").trim();
  if (!hasOffsets) {
    const chunks = events.map((e) => ({
      start: e.tStartMs || 0, end: (e.tStartMs || 0) + (e.dDurationMs || 2000),
      text: cleanCue(clean(e.segs.map((x) => x.utf8 || "").join("")))
    })).filter((c) => c.text);
    return opts.merge ? mergeSentences(chunks) : chunks;
  }
  const words = [];
  let inBr = false;
  for (const e of events) {
    for (const x of e.segs) {
      const w = clean(x.utf8 || "");
      if (!w) continue;
      if (inBr) { if (w.includes("]")) inBr = false; continue; }          // داخل [ ... ]
      if (w.includes("[")) { if (!w.includes("]")) inBr = true; continue; }
      const cw = cleanCue(w);
      if (!cw) continue;
      const t = (e.tStartMs || 0) + (x.tOffsetMs || 0);
      if (words.length && t < words[words.length - 1].t) continue;
      words.push({ t, w: cw });
    }
  }
  return buildAsrChunks(words, punct);
}

function ensureTrack(name) {
  if (!baseUrl || tracks[name]) return;
  tracks[name] = { state: "loading", chunks: [] };
  const u = new URL(baseUrl);
  u.searchParams.delete("tlang");
  if (name !== "orig") u.searchParams.set("tlang", name);
  u.searchParams.set("fmt", "json3");
  const myKey = srcKey;
  fetch(u.href, { credentials: "include" })
    .then((r) => r.text())
    .then((txt) => {
      if (myKey !== srcKey) return;
      const chunks = parseTrack(JSON.parse(txt), { punct: settings.autoPunct, merge: name === "orig" });
      tracks[name] = chunks.length ? { state: "ok", chunks } : { state: "fail", chunks: [] };
    })
    .catch(() => { if (myKey === srcKey) tracks[name] = { state: "fail", chunks: [] }; });
}

function chunkIndexAt(chunks, t) {
  let lo = 0, hi = chunks.length - 1, idx = -1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (chunks[mid].start <= t) { idx = mid; lo = mid + 1; } else hi = mid - 1;
  }
  return idx;
}
function findChunk(chunks, t) {
  const i = chunkIndexAt(chunks, t);
  return i >= 0 && t < chunks[i].end ? chunks[i] : null;
}

/* ---- ترجمة احتياطية (Google) + تحميل مسبق لكل الفيديو ---- */
let lastProviderError = "";
const svc = { until: 0, prog: 0, needsClick: false, armed: false };      // حالة الخدمة للمؤشر
const noteRate = (secs) => { if (secs) svc.until = Date.now() + secs * 1000; };
const isLLM = () => settings.provider === "claude" || settings.provider === "openai";

/* ---- ترجمة فورية لسطر واحد (للبث المباشر) ---- */
function fallbackTranslate(text, code, useProvider) {
  const key = code + "|" + (useProvider ? "p|" : "") + text;
  if (!fb.has(key)) {
    fb.set(key, "…");
    chrome.runtime.sendMessage({ type: "translate", text, to: code, src: srcLang(), useProvider: !!useProvider, urgent: !!useProvider }, (res) => {
      if (chrome.runtime.lastError || !res) { fb.set(key, ""); return; }
      if (res.rateLimited) { noteRate(res.rateLimited); setTimeout(() => fb.delete(key), res.rateLimited * 1000 + 500); }
      if (res.error && !res.text) { fb.set(key, ""); return; }
      if (res.fallbackReason) lastProviderError = res.fallbackReason;
      fb.set(key, cleanCue(res.text || ""));
    });
  }
  return fb.get(key);
}
const prepKey = (code) => srcKey + "|" + code + "|" + settings.provider + "|" + settings.dialect;

/* ---- مترجم Chrome المدمج (على الجهاز، بلا حدود) — تجريبي ---- */
const localT = {};
const localCode = (c) => (c === "zh-CN" ? "zh" : (c || "").toLowerCase().split("-")[0]);
function armClick() {
  if (svc.armed) return;
  svc.armed = true;
  const h = () => {
    svc.armed = false; svc.needsClick = false;
    document.removeEventListener("pointerdown", h, true); document.removeEventListener("keydown", h, true);
  };
  document.addEventListener("pointerdown", h, true); document.addEventListener("keydown", h, true);
}
function getLocalTranslator(from, to) {
  if (typeof Translator === "undefined") return Promise.reject(new Error("Chrome translator not available (needs desktop Chrome 138+)"));
  const key = from + ">" + to;
  if (localT[key]) return localT[key];
  const pr = (async () => {
    const av = await Translator.availability({ sourceLanguage: from, targetLanguage: to });
    if (av === "unavailable") throw new Error("Language pair not supported: " + key);
    return Translator.create({
      sourceLanguage: from, targetLanguage: to,
      monitor(m) { m.addEventListener("downloadprogress", (ev) => { svc.prog = Math.round(ev.loaded * 100); }); }
    });
  })();
  localT[key] = pr;
  pr.then(() => { svc.prog = 0; }, (err) => {
    delete localT[key];
    if (err && err.name === "NotAllowedError") { svc.needsClick = true; armClick(); }   // يحتاج نقرة من المستخدم
  });
  return pr;
}
async function localTranslate(text, from, to) { return (await getLocalTranslator(from, to)).translate(text); }

/* ---- نافذة متحركة: نترجم القادم فقط (لا الفيديو كله) ---- */
const WINDOW_MS = 60000;
let lastPump = 0;
function getPrep(code, n) {
  const pk = prepKey(code);
  let p = prepMap.get(pk);
  if (!p) {
    p = { code, n, texts: new Array(n), st: new Uint8Array(n), att: new Uint8Array(n), retryAt: new Array(n).fill(0), inflight: 0, batches: 0 };
    prepMap.set(pk, p);
  }
  return p;
}
// st: 0 لم تُطلب · 1 قيد الترجمة · 2 تمت · 3 فشلت (تُعاد لاحقاً)
function pumpPrep(l, chunks, origIdx, t, paused) {
  const p = getPrep(l.code, chunks.length);
  const llm = isLLM(), local = settings.provider === "chrome";
  if (p.inflight >= (llm || local ? 1 : 2)) return p;
  const now = Date.now();
  const win = paused ? t + 12000 : t + (local ? 120000 : WINDOW_MS);
  const maxBatch = llm ? (p.batches === 0 ? 3 : 8) : 1;
  const need = [];
  for (let i = Math.max(0, origIdx - 1); i < chunks.length && chunks[i].start <= win; i++) {
    if (p.st[i] === 0 || (p.st[i] === 3 && now >= p.retryAt[i] && p.att[i] < 3)) need.push(i);
    if (need.length >= maxBatch) break;
  }
  if (!need.length) return p;
  need.forEach((i) => { p.st[i] = 1; });
  p.inflight++; p.batches++;
  const myKey = srcKey;
  const finish = (res, activationErr) => {
    p.inflight--;
    if (myKey !== srcKey) return;
    const ok = !chrome.runtime.lastError && res && !res.error && Array.isArray(res.texts) && res.texts.length === need.length;
    if (res && res.fallbackReason) lastProviderError = res.fallbackReason;
    if (res && res.rateLimited) noteRate(res.rateLimited);
    need.forEach((i, j) => {
      const tx = ok ? cleanCue(res.texts[j] || "") : "";
      if (tx) { p.texts[i] = tx; p.st[i] = 2; return; }
      p.st[i] = 3;
      if (activationErr) p.retryAt[i] = Date.now() + 1500;                           // بانتظار نقرة المستخدم
      else if (res && res.rateLimited) p.retryAt[i] = Date.now() + res.rateLimited * 1000 + 500;   // لا نحسبها محاولة فاشلة
      else { p.att[i]++; p.retryAt[i] = Date.now() + 6000; }
    });
  };
  const viaBackground = () => {
    const first = need[0];
    const ctxTexts = llm && first > 0 ? chunks.slice(Math.max(0, first - 2), first).map((c) => c.text) : [];
    chrome.runtime.sendMessage({ type: "translateBatch", texts: need.map((i) => chunks[i].text), context: ctxTexts, to: l.code, src: srcLang() }, (res) => finish(res));
  };
  if (local) {
    localTranslate(chunks[need[0]].text, localCode(srcLang()), localCode(l.code))
      .then((tx) => finish({ texts: [tx] }))
      .catch((err) => { if (err && err.name === "NotAllowedError") finish(null, true); else viaBackground(); });   // احتياط: Google
  } else viaBackground();
  return p;
}

/* ---- مؤشر حالة الخدمة على الفيديو ---- */
function updateStatus() {
  if (!prepEl) return;
  let msg = "";
  const left = Math.ceil((svc.until - Date.now()) / 1000);
  if (left > 0) msg = T("c_google_paused", { n: left });
  else if (svc.needsClick) msg = T("c_click_chrome");
  else if (svc.prog > 0 && svc.prog < 100) msg = T("c_downloading", { n: svc.prog });
  if (msg) { prepEl.textContent = msg; prepEl.classList.add("show"); } else prepEl.classList.remove("show");
}

/* ===================== القراءة الصوتية (TTS) ===================== */
let ttsToken = 0, savedVol = null;
let speechActive = false, waitingTTS = false, waitTimer = null, smartSlotEnd = 0;
const msPerChar = {};                                   // يتعلّم سرعة النطق الفعلية لكل لغة
const defMs = (b) => (/^(ja|zh|ko)/.test(b) ? 220 : 75);
const baseLang = (l) => (l || "en").toLowerCase().replace("_", "-").split("-")[0];

/* مدة التوقف الطبيعية (بالملّي ثانية) بعد كل علامة */
const PAUSE_MS = { ",": 220, "،": 220, ";": 300, "؛": 300, ":": 260, ".": 480, "。": 480,
                   "!": 500, "！": 500, "?": 520, "؟": 520, "？": 520, "…": 420, "，": 220, "、": 220 };
/* كلمات الربط: نضع قبلها فاصلة إن كانت الجملة طويلة وبلا ترقيم */
const CONJ = {
  en: ["and", "but", "because", "so", "which", "while", "when", "although"],
  fr: ["et", "mais", "parce", "donc", "qui", "quand", "alors"],
  es: ["y", "pero", "porque", "entonces", "que", "cuando", "aunque"],
  de: ["und", "aber", "weil", "dass", "wenn", "obwohl"],
  ar: ["لكن", "لأن", "ثم", "حيث", "عندما", "بينما", "الذي", "التي", "لكنّ", "إذ"]
};
function addSoftBreaks(text, lang) {
  const b = baseLang(lang), list = CONJ[b];
  if (!list || /[,،;؛:.!?؟…]/.test(text.slice(0, -1))) return text;
  const words = text.split(/\s+/);
  if (words.length < 14) return text;
  let best = -1, bd = 1e9;
  const mid = words.length / 2;
  words.forEach((w, i) => {
    if (i < 4 || i > words.length - 4) return;
    if (list.includes(w.toLowerCase().replace(/[^\p{L}]/gu, "")) && Math.abs(i - mid) < bd) { bd = Math.abs(i - mid); best = i; }
  });
  if (best < 0) return text;
  words[best - 1] += b === "ar" ? "،" : ",";
  return words.join(" ");
}
function splitPhrases(text, commas) {
  const re = commas ? /(?<=[.!?؟…;؛:,،])\s+|(?<=[。！？，、；：])/ : /(?<=[.!?؟…])\s+|(?<=[。！？])/;
  const parts = text.split(re).map((x) => x.trim()).filter(Boolean);
  const out = parts.map((p) => ({ text: p, pause: PAUSE_MS[p.slice(-1)] || 0 }));
  return out.length ? out : [{ text, pause: 0 }];
}

function voiceScore(v, lang) {
  let sc = 0;
  if (v.lang.replace("_", "-").toLowerCase() === lang.toLowerCase()) sc += 2;
  if (/natural|neural|premium|enhanced|siri/i.test(v.name)) sc += 4;
  if (/google/i.test(v.name)) sc += 3;
  if (v.localService === false) sc += 1;
  return sc;
}
function pickVoice(lang) {
  if (!("speechSynthesis" in window)) return null;
  const voices = speechSynthesis.getVoices(), base = baseLang(lang);
  const chosen = settings.voices && settings.voices[base];
  if (chosen) { const v = voices.find((x) => x.name === chosen); if (v) return v; }
  const c = voices.filter((v) => baseLang(v.lang) === base);
  if (!c.length) return null;
  c.sort((a, b) => voiceScore(b, lang) - voiceScore(a, lang));
  return c[0];
}
/* الأصوات الشبكية تتوقف عند الفاصلة وحدها، فنقسم عند نهاية الجملة فقط؛ المحلية نتحكم نحن بتوقفها */
const isNetVoice = (lang) => { const v = pickVoice(lang); return !!v && v.localService === false; };
function estimateSpeech(text, lang, rate) {
  const ph = splitPhrases(addSoftBreaks(text, lang), !isNetVoice(lang));
  const chars = ph.reduce((a, p) => a + p.text.length, 0);
  const pauses = ph.slice(0, -1).reduce((a, p) => a + p.pause, 0) * settings.pauseScale;
  return (chars * (msPerChar[baseLang(lang)] || defMs(baseLang(lang)))) / rate + pauses / Math.max(1, rate);
}

function holdVideo() {
  waitingTTS = true;
  clearTimeout(waitTimer);
  waitTimer = setTimeout(releaseVideo, 12000);          // حماية: لا يبقى الفيديو متوقفاً للأبد
}
function releaseVideo() {
  clearTimeout(waitTimer);
  if (waitingTTS) { waitingTTS = false; const v = getVideo(); v && v.paused && v.play(); }
}

function speak(text, lang, opts = {}) {
  if (!text || !("speechSynthesis" in window)) return;
  text = sanitizeForSpeech(text);
  if (!text) return;
  speechSynthesis.cancel();
  const token = ++ttsToken;
  const video = getVideo();
  const rate = opts.rate || settings.ttsRate;
  lang = lang || "en";
  const voice = pickVoice(lang);
  const net = !!voice && voice.localService === false;
  const phrases = splitPhrases(addSoftBreaks(text, lang), !net);
  if (settings.duck && video) {
    if (savedVol === null) savedVol = video.volume;
    video.volume = Math.max(0, savedVol * 0.25);
  }
  speechActive = true;
  let i = 0, spokenMs = 0, spokenChars = 0;
  const finish = (ok) => {
    if (token !== ttsToken) return;
    speechActive = false; smartSlotEnd = 0;
    if (video && savedVol !== null) { video.volume = savedVol; savedVol = null; }
    if (ok && spokenChars > 8 && spokenMs > 300) {      // تعلّم سرعة النطق الحقيقية
      const b = baseLang(lang), per = (spokenMs * rate) / spokenChars;
      msPerChar[b] = msPerChar[b] ? msPerChar[b] * 0.6 + per * 0.4 : per;
    }
    releaseVideo();
  };
  const next = () => {
    if (token !== ttsToken) return;
    if (i >= phrases.length) { finish(true); return; }
    const ph = phrases[i++];
    const u = new SpeechSynthesisUtterance(ph.text);
    u.lang = lang; u.rate = rate;
    if (voice) u.voice = voice;
    const last = ph.text.slice(-1);
    u.pitch = /[?؟？]/.test(last) ? 1.08 : /[.。!！]/.test(last) ? 0.97 : 1;   // نبرة طبيعية: صعود للسؤال وهبوط للنقطة
    let t0 = 0;
    u.onstart = () => { t0 = performance.now(); };
    u.onend = () => {
      if (token !== ttsToken) return;
      if (t0) { spokenMs += performance.now() - t0; spokenChars += ph.text.length; }
      const gap = i < phrases.length ? (ph.pause * settings.pauseScale) / Math.max(1, rate) : 0;
      if (gap > 0) setTimeout(next, gap); else next();
    };
    u.onerror = () => { if (token === ttsToken) finish(false); };
    speechSynthesis.speak(u);
  };
  next();
  setTimeout(() => { if (token === ttsToken && speechActive) finish(false); }, estimateSpeech(text, lang, rate) + 8000);
}

function handleAutoRead(video, t, orig, origIdx, origChunk, trList) {
  const smart = settings.ttsMode === "smart";
  // Quick-pause mode: reading starts with the sentence and speeds up a little. If the speaker is too fast
  // and the reading isn't finished when the sentence ends, pause the video only until the reading ends.
  if (smart && speechActive && smartSlotEnd && t >= smartSlotEnd - 80 && !video.paused && !waitingTTS) {
    video.pause(); holdVideo();
  }
  if (!origChunk || video.paused) return;
  const key = origChunk.start + "|" + settings.autoRead;
  if (lastReadKey === key) return;
  let ti = null;
  if (settings.autoRead === "orig") ti = { text: origChunk.text, lang: srcLang() };
  else { const l = trList.find((x) => x.text && x.text !== "…"); if (l) ti = { text: l.text, lang: l.lang }; }
  if (!ti) return;

  if (smart) {
    lastReadKey = key;
    const next = orig.chunks[origIdx + 1];
    const slot = Math.max(900, (next ? next.start : origChunk.end) - origChunk.start);
    const remaining = Math.max(500, slot - (t - origChunk.start));
    const est = estimateSpeech(ti.text, ti.lang, settings.ttsRate);
    let rate = settings.ttsRate;
    if (est > remaining) rate = Math.min(1.5, (settings.ttsRate * est) / remaining);   // speed up a little, but stay easy to understand
    smartSlotEnd = origChunk.start + slot;
    speak(ti.text, ti.lang, { rate });
  } else if (t >= origChunk.end - 150) {               // وضع «قراءة ثم متابعة»
    lastReadKey = key;
    video.pause(); holdVideo();
    speak(ti.text, ti.lang);
  }
}

/* ===================== الصندوق ===================== */
let segCache = { lang: null, seg: null };
function getSegmenter() {
  if (typeof Intl === "undefined" || !Intl.Segmenter) return null;
  const l = srcLang();
  if (segCache.lang !== l) {
    try { segCache = { lang: l, seg: new Intl.Segmenter(l, { granularity: "word" }) }; }
    catch (_) { segCache = { lang: l, seg: null }; }
  }
  return segCache.seg;
}
function stopEvents(el, evs) { evs.forEach((ev) => el.addEventListener(ev, (e) => e.stopPropagation())); }

function ensureBox() {
  player = document.getElementById(SEL.player);
  if (!player) return false;
  if (box && box.isConnected) return true;

  box = document.createElement("div");
  box.id = "dsub-box";
  box.style.display = "none";
  const rzL = document.createElement("div"); rzL.className = "dsub-rz dsub-rz-l";
  const rzR = document.createElement("div"); rzR.className = "dsub-rz dsub-rz-r";
  linesEl = document.createElement("div"); linesEl.className = "dsub-lines";
  box.append(rzL, linesEl, rzR);
  player.appendChild(box);

  toastEl = document.createElement("div"); toastEl.id = "dsub-toast"; player.appendChild(toastEl);
  prepEl = document.createElement("div"); prepEl.id = "dsub-prep"; player.appendChild(prepEl);

  stopEvents(box, ["click", "dblclick", "mouseup", "pointerup", "pointerdown", "touchstart"]);
  box.addEventListener("mousedown", startDrag);
  rzL.addEventListener("mousedown", startResize);
  rzR.addEventListener("mousedown", startResize);
  lineKey = "";
  applyStyle();
  return true;
}

function applyStyle() {
  document.documentElement.classList.toggle("dsub-on", settings.enabled);
  if (!box) return;
  const pos = settings.pos && typeof settings.pos.x === "number" ? settings.pos : { x: 50, b: 14 };
  Object.assign(box.style, {
    left: pos.x + "%", bottom: pos.b + "%", top: "auto",
    transform: "translateX(-50%)", width: settings.width + "%",
    background: `rgba(12,12,20,${settings.bgOpacity})`,
    fontFamily: FONTS[settings.font] || FONTS.system, fontWeight: String(settings.weight)
  });
  box.classList.toggle("dsub-quiz", !!settings.quiz);
  if (!settings.enabled) box.style.display = "none";
}

function startDrag(e) {
  if (e.button !== 0 || e.target.closest(".dsub-btn")) return;
  e.stopPropagation();
  const pr = player.getBoundingClientRect(), er = box.getBoundingClientRect();
  const sx = e.clientX, sy = e.clientY;
  const downWord = e.target.closest && e.target.closest(".dsub-word");
  const cx0 = er.left + er.width / 2 - pr.left, b0 = pr.bottom - er.bottom;
  let moved = false;
  const move = (ev) => {
    const dx = ev.clientX - sx, dy = ev.clientY - sy;
    if (!moved && Math.hypot(dx, dy) < 4) return;
    moved = true; dragged = true; box.classList.add("dsub-moving");
    settings.pos = { x: clamp(((cx0 + dx) / pr.width) * 100, 10, 90), b: clamp(((b0 - dy) / pr.height) * 100, 2, 80) };
    applyStyle();
  };
  const up = () => {
    document.removeEventListener("mousemove", move, true);
    document.removeEventListener("mouseup", up, true);
    box.classList.remove("dsub-moving");
    if (moved) { chrome.storage.sync.set({ pos: settings.pos }); setTimeout(() => (dragged = false), 60); }
    else if (downWord && downWord.isConnected) openLookup(downWord);       // نقرة على كلمة
  };
  document.addEventListener("mousemove", move, true);
  document.addEventListener("mouseup", up, true);
}

function startResize(e) {
  e.preventDefault(); e.stopPropagation();
  const pr = player.getBoundingClientRect(), er = box.getBoundingClientRect();
  const center = er.left + er.width / 2;
  const move = (ev) => {
    settings.width = Math.round(clamp((Math.abs(ev.clientX - center) * 2 / pr.width) * 100, 30, 96));
    applyStyle();
  };
  const up = () => {
    document.removeEventListener("mousemove", move, true);
    document.removeEventListener("mouseup", up, true);
    chrome.storage.sync.set({ width: settings.width });
  };
  document.addEventListener("mousemove", move, true);
  document.addEventListener("mouseup", up, true);
}

const scaleFactor = () => (settings.autoScale && player ? clamp(player.clientWidth / 960, 0.7, 1.8) : 1);

function makeLineEl(l) {
  const el = document.createElement("div");
  el.className = "dsub-line dsub-" + l.kind;
  el.dir = "auto";
  const t = document.createElement("span");
  t.className = "dsub-text";
  el.appendChild(t);
  if (l.kind !== "hint") {
    const b = document.createElement("button");
    b.className = "dsub-btn"; b.type = "button"; b.title = T("c_listen"); b.textContent = "🔊";
    b.addEventListener("click", (e) => {
      e.stopPropagation();
      const ln = el._line;
      speak(ln.text, ln.kind === "orig" ? srcLang() : ln.lang);
    });
    el.appendChild(b);
  }
  return el;
}

function fillText(t, l) {
  t.textContent = "";
  if (l.kind !== "orig") { t.textContent = l.text; return; }
  const seg = getSegmenter();
  const addWord = (w) => { const s = document.createElement("span"); s.className = "dsub-word"; s.textContent = w; t.appendChild(s); };
  if (seg) {
    for (const p of seg.segment(l.text)) { if (p.isWordLike) addWord(p.segment); else t.appendChild(document.createTextNode(p.segment)); }
  } else {
    l.text.split(/(\s+)/).forEach((p) => { if (!p.trim()) t.appendChild(document.createTextNode(p)); else addWord(p); });
  }
}

function renderLines(lines) {
  curLines = lines;
  const visible = lines.filter((l) => l.text);
  if (!visible.length) { box.style.display = "none"; return; }
  box.style.display = "block";
  const k = scaleFactor();
  const key = visible.map((l) => l.id).join(",");
  if (key !== lineKey) {
    linesEl.textContent = "";
    visible.forEach((l) => linesEl.appendChild(makeLineEl(l)));
    lineKey = key;
  }
  visible.forEach((l, i) => {
    const el = linesEl.children[i];
    el._line = l;
    if (el.dataset.text !== l.text) {
      fillText(el.firstChild, l);
      el.dataset.text = l.text;
      el.classList.remove("dsub-in"); void el.offsetWidth; el.classList.add("dsub-in");
    }
    el.style.fontSize = l.size * k + "px";
    el.style.color = l.color;
  });
  const maxH = player.clientHeight * 0.4;
  const reserved = lines.reduce((a, l) => a + l.size * k * 1.45, 0) + (lines.length - 1) * 15 + 22;
  box.style.minHeight = Math.min(reserved, maxH * 0.9) + "px";
  if (settings.autoShrink) {
    let f = 1;
    for (let i = 0; i < 6 && box.offsetHeight > maxH; i++) {
      f *= 0.9;
      visible.forEach((l, j) => (linesEl.children[j].style.fontSize = l.size * k * f + "px"));
    }
  }
}

let toastT;
function toast(msg) {
  if (!toastEl) return;
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  clearTimeout(toastT);
  toastT = setTimeout(() => toastEl.classList.remove("show"), 1500);
}

/* ===================== البحث عن كلمة + القاموس ===================== */
const psId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
function saveEntry(entry) {
  const full = Object.assign({
    sentence: curOrigChunk ? curOrigChunk.text : "",
    sentenceTr: (curLines.find((l) => l.kind === "tr" && l.text && l.text !== "…") || {}).text || "",
    videoId: curVideoId(), time: Math.floor((getVideo() || { currentTime: 0 }).currentTime),
    date: Date.now()
  }, entry);
  chrome.storage.local.get({ dict: [] }, ({ dict }) => {
    if (dict.some((d) => d.word.toLowerCase() === full.word.toLowerCase() && d.videoId === full.videoId && d.sentence === full.sentence)) {
      toast(T("c_already")); return;
    }
    const max = limits().maxWords;
    if (dict.length >= max) { toast(T("c_word_limit", { n: max })); return; }
    full.id = full.id || psId();
    dict.push(full);
    chrome.storage.local.set({ dict }, () => toast(T("c_saved_toast")));
  });
}

function closeLookup(mode = "drop") {
  if (lookupEl) { lookupEl.remove(); lookupEl = null; }
  if (mode === "resume" && pausedByUs) { const v = getVideo(); v && v.play(); }
  if (mode !== "keep") pausedByUs = false;
}

const lookCache = new Map();
function lookupWord(word, sentence, code, cb) {
  const ck = code + "|" + word.toLowerCase() + "|" + (isLLM() ? sentence : "");
  if (lookCache.has(ck)) { cb(lookCache.get(ck)); return; }
  const done = (res) => { if (res && res.main && !res.error) lookCache.set(ck, res); cb(res); };
  const viaBg = () => chrome.runtime.sendMessage({ type: "lookup", word, sentence, to: code }, (res) => {
    const lastErr = chrome.runtime.lastError && chrome.runtime.lastError.message;
    if (res && res.rateLimited) noteRate(res.rateLimited);
    done(lastErr ? { error: lastErr } : res);
  });
  if (settings.provider === "chrome") {
    localTranslate(word, localCode(srcLang()), localCode(code))
      .then((tx) => (tx ? done({ main: tx, alts: [], note: "" }) : viaBg())).catch(() => viaBg());
  } else viaBg();
}

function openLookup(wordEl) {
  const word = wordEl.textContent.trim();
  if (!word) return;
  const video = getVideo();
  closeLookup("keep");
  if (settings.pauseOnLookup && video && !video.paused) { video.pause(); pausedByUs = true; }

  const pr = player.getBoundingClientRect(), wr = wordEl.getBoundingClientRect();
  const el = document.createElement("div");
  el.id = "dsub-lookup";
  stopEvents(el, ["click", "dblclick", "mousedown", "mouseup", "pointerdown", "pointerup", "touchstart"]);

  const head = document.createElement("div"); head.className = "lk-head";
  const w = document.createElement("span"); w.className = "lk-word"; w.dir = "auto"; w.textContent = word;
  const sp = document.createElement("button"); sp.className = "lk-ico"; sp.textContent = "🔊"; sp.title = T("c_listen");
  sp.onclick = () => speak(word, srcLang());
  const cl = document.createElement("button"); cl.className = "lk-ico"; cl.textContent = "✕"; cl.title = T("c_close");
  cl.onclick = () => closeLookup("resume");
  head.append(w, sp, cl);
  el.appendChild(head);

  // النافذة قابلة للتحريك: اسحبها من الرأس
  head.addEventListener("mousedown", (e) => {
    if (e.target.closest("button")) return;
    e.preventDefault();
    const r = el.getBoundingClientRect(), p2 = player.getBoundingClientRect();
    const ox = e.clientX - r.left, oy = e.clientY - r.top;
    el.style.transform = "none"; el.style.bottom = "auto";
    el.style.left = r.left - p2.left + "px"; el.style.top = r.top - p2.top + "px";
    const move = (ev) => {
      el.style.left = clamp(ev.clientX - ox - p2.left, 0, p2.width - r.width) + "px";
      el.style.top = clamp(ev.clientY - oy - p2.top, 0, p2.height - r.height) + "px";
    };
    const up = () => { document.removeEventListener("mousemove", move, true); document.removeEventListener("mouseup", up, true); };
    document.addEventListener("mousemove", move, true);
    document.addEventListener("mouseup", up, true);
  });

  const translations = {};
  const sentence = curOrigChunk ? curOrigChunk.text : "";
  const srcBase = baseLang(srcLang());
  let codes = activeLangs().map((l) => l.code).filter((c) => baseLang(c) !== srcBase);
  if (!codes.length) codes = [["ar", "en"].find((c) => c !== srcBase)];
  const rowFor = (code) => {
    const row = document.createElement("div"); row.className = "lk-row";
    const tag = document.createElement("span"); tag.className = "lk-tag"; tag.textContent = code.split("-")[0].toUpperCase();
    const body = document.createElement("div"); body.className = "lk-body";
    const val = document.createElement("span"); val.className = "lk-val"; val.dir = "auto";
    const alt = document.createElement("div"); alt.className = "lk-alt"; alt.dir = "auto";
    body.append(val, alt); row.append(tag, body);
    const run = () => {
      val.textContent = "…"; alt.textContent = ""; alt.style.cursor = ""; alt.onclick = null;
      lookupWord(word, sentence, code, (res) => {
        if (!res || res.error || !res.main) {
          const limited = res && res.rateLimited;
          val.textContent = limited ? T("c_paused_short") : T("c_tr_fail");
          alt.textContent = limited ? T("c_try_after", { n: res.rateLimited })
                                    : ((res && res.error) || T("c_no_result")) + T("c_click_retry");
          alt.style.cursor = "pointer"; alt.onclick = run;
          return;
        }
        val.textContent = res.main; translations[code] = res.main;
        const extra = [];
        if (res.alts && res.alts.length) extra.push(res.alts.join(psUiLang(settings.uiLang) === "ar" ? "، " : ", "));
        if (res.note) extra.push(res.note);
        alt.textContent = extra.join(" · ");
      });
    };
    run();
    return row;
  };
  el.appendChild(rowFor(codes[0]));                               // لغة واحدة أولاً لتقليل الطلبات
  if (codes.length > 1) {
    const more = document.createElement("button"); more.className = "lk-more";
    more.textContent = T("c_more_langs", { n: codes.length - 1 });
    more.onclick = () => { codes.slice(1).forEach((c) => more.before(rowFor(c))); more.remove(); };
    el.appendChild(more);
  }

  const save = document.createElement("button"); save.className = "lk-save"; save.textContent = T("c_save_word");
  save.onclick = () => { saveEntry({ word, translations }); save.disabled = true; save.textContent = T("c_saved"); };
  el.appendChild(save);

  el.style.left = clamp(wr.left + wr.width / 2 - pr.left, 140, pr.width - 140) + "px";
  if (wr.top - pr.top < 190) el.style.top = wr.bottom - pr.top + 10 + "px";
  else el.style.bottom = pr.bottom - wr.top + 10 + "px";
  player.appendChild(el);
  lookupEl = el;
}

document.addEventListener("mousedown", (e) => {
  if (lookupEl && !lookupEl.contains(e.target) && !(e.target.closest && e.target.closest(".dsub-word"))) closeLookup("drop");
}, true);
document.addEventListener("keydown", (e) => { if (e.code === "Escape" && lookupEl) closeLookup("resume"); }, true);

/* ===================== أوامر الاختصارات ===================== */
function seekTo(c) {
  const v = getVideo();
  if (!v || !c) return;
  v.currentTime = c.start / 1000 + 0.02;
  pausedChunk = null; lastReadKey = "";
  releaseVideo();
  if (v.paused) v.play();
}
function toggleSetting(key, label) {
  settings[key] = !settings[key];
  chrome.storage.sync.set({ [key]: settings[key] });
  applyStyle();
  toast(label + ": " + (settings[key] ? T("c_on") : T("c_off")));
}
const origChunks = () => (tracks.orig && tracks.orig.state === "ok" ? tracks.orig.chunks : null);

const ACTIONS = {
  prev() {
    const ch = origChunks(), v = getVideo(); if (!ch || !v) return;
    const t = v.currentTime * 1000, i = chunkIndexAt(ch, t);
    seekTo(ch[clamp(t - (ch[i] ? ch[i].start : 0) > 1200 ? i : i - 1, 0, ch.length - 1)]);
  },
  next() {
    const ch = origChunks(), v = getVideo(); if (!ch || !v) return;
    seekTo(ch[clamp(chunkIndexAt(ch, v.currentTime * 1000) + 1, 0, ch.length - 1)]);
  },
  repeat() {
    const ch = origChunks(), v = getVideo(); if (!ch || !v) return;
    seekTo(ch[Math.max(0, chunkIndexAt(ch, v.currentTime * 1000))]);
  },
  loop() {
    if (loopChunk) { loopChunk = null; toast(T("c_loop_off")); return; }
    if (curOrigChunk) { loopChunk = curOrigChunk; toast(T("c_loop_on")); }
  },
  hideTrans() { toggleSetting("hideTrans", T("a_hideTrans")); },
  original() { toggleSetting("showOriginal", T("original_text")); },
  quiz() { toggleSetting("quiz", T("a_quiz")); },
  autoPause() { toggleSetting("autoPause", T("a_autoPause")); },
  speak() { if (curOrigChunk) speak(curOrigChunk.text, srcLang()); },
  save() { if (curOrigChunk) saveEntry({ word: curOrigChunk.text }); else toast(T("c_no_sentence")); },
  quizNow() { quizOpen("manual"); }
};

/* ===================== وضع احتياطي: قراءة الترجمة من الشاشة ===================== */
const readDomCaption = () =>
  cleanCue(Array.from(document.querySelectorAll(SEL.captionSegment)).map((x) => x.textContent.trim()).filter(Boolean).join(" "));

function renderDomMode(dom, t) {
  domMode = true;
  if (dom !== domText) { domText = dom; domSince = Date.now(); }
  curOrigChunk = { start: t, end: t + 2500, text: dom };
  const stable = Date.now() - domSince > 500;      // لا نترجم كلمة كلمة
  const lines = [];
  if (settings.showOriginal) lines.push({ id: "orig", kind: "orig", text: dom, size: settings.origSize, color: settings.origColor });
  if (!settings.hideTrans) {
    for (const l of activeLangs()) {
      if (baseLang(l.code) === baseLang(srcLang())) continue;
      lines.push({ id: "l-" + l.code, kind: "tr", lang: l.code, text: stable ? fallbackTranslate(dom, l.code, true) : "…", size: l.size, color: l.color });
    }
  }
  renderLines(lines);
}

/* ===================== الحلقة الرئيسية ===================== */
const hintLine = (text) => ({ id: "hint", kind: "hint", text, size: 16, color: "#ffffff" });

function tick() {
  if (!settings.enabled || !ensureBox()) return;
  const video = getVideo();
  if (!video) return;
  if (typeof quizTick === "function") quizTick(video);
  const t = video.currentTime * 1000;
  if (t < prevT - 300) lastReadKey = "";
  prevT = t;

  if (!baseUrl) {
    domMode = false;
    const now = Date.now();
    if (ccTries < MAX_TRIES && now - lastTry > 2000) {
      window.postMessage({ source: "dsub-cmd", type: "ensureCC", force: ccTries >= 3 }, "*");
      ccTries++; lastTry = now;
    }
    const dom = ccTries >= 3 ? readDomCaption() : "";
    if (dom) { renderDomMode(dom, t); updateStatus(); return; }
    renderLines([hintLine(ccTries < MAX_TRIES ? T("c_loading") : T("c_no_subs"))]);
    updateStatus();
    return;
  }
  domMode = false;

  ensureTrack("orig");
  const orig = tracks.orig;
  if (orig && orig.state === "fail") { renderLines([hintLine(T("c_load_fail"))]); return; }
  const okOrig = orig && orig.state === "ok";
  const origIdx = okOrig ? chunkIndexAt(orig.chunks, t) : -1;
  const origChunk = okOrig && origIdx >= 0 && t < orig.chunks[origIdx].end ? orig.chunks[origIdx] : null;
  curOrigChunk = origChunk;

  const waitMode = settings.autoRead !== "off" && settings.ttsMode === "wait";
  if (loopChunk && !video.paused && t >= loopChunk.end - 60) {
    video.currentTime = loopChunk.start / 1000 + 0.02;
  } else if (settings.autoPause && !waitMode && !loopChunk && origChunk && !video.paused &&
             t >= origChunk.end - 150 && pausedChunk !== origChunk) {
    video.pause(); pausedChunk = origChunk;
  }

  const srcBase = baseLang(srcLang());
  const doPump = Date.now() - lastPump > 600 && !document.hidden;
  if (doPump) lastPump = Date.now();
  const trList = [];
  for (const l of activeLangs()) {
    if (baseLang(l.code) === srcBase) continue;                  // لا نترجم اللغة إلى نفسها
    const name = ytCode(l.code);
    let text = "";
    if (settings.smartTr && okOrig) {
      const p = doPump ? pumpPrep(l, orig.chunks, origIdx, t, video.paused) : getPrep(l.code, orig.chunks.length);
      if (origChunk) {
        const tx = p.texts[origIdx];
        const failed = p.st[origIdx] === 3;
        // Fallback: when our translation failed or Google is pausing us, use YouTube's own auto-translation.
        const yt = !tx && (failed || svc.until > Date.now()) ? ytTrackText(name, t) : "";
        text = tx || yt || (failed && p.att[origIdx] >= 3 ? "⚠" : "…");
      }
    } else {
      ensureTrack(name);
      const tr = tracks[name];
      if (tr && tr.state === "ok") {
        const c = findChunk(tr.chunks, t);
        text = c ? c.text : "";
      } else if (tr && tr.state === "fail" && okOrig) {
        text = origChunk ? fallbackTranslate(origChunk.text, l.code) : "";
      } else if (origChunk) {
        text = "…";
      }
    }
    trList.push({ id: "l-" + l.code, kind: "tr", lang: l.code, text, size: l.size, color: l.color });
  }
  const lines = [];
  if (settings.showOriginal) {
    lines.push({ id: "orig", kind: "orig", text: origChunk ? origChunk.text : "", size: settings.origSize, color: settings.origColor });
  }
  if (!settings.hideTrans) lines.push(...trList);
  renderLines(lines);
  updateStatus();

  if (settings.autoRead !== "off" && okOrig) handleAutoRead(video, t, orig, origIdx, origChunk, trList);
}

function ytTrackText(name, t) {
  ensureTrack(name);
  const tr = tracks[name];
  if (!tr || tr.state !== "ok") return "";
  const c = findChunk(tr.chunks, t);
  return c ? c.text : "";
}

function reset() {
  ccTries = 0; lastTry = 0; baseUrl = null; srcKey = null; tracks = {}; lineKey = "";
  loopChunk = null; pausedChunk = null; curOrigChunk = null; lastReadKey = "";
  domMode = false; domText = ""; smartSlotEnd = 0;
  releaseVideo();
  closeLookup("drop");
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  if (box) box.style.display = "none";
  if (prepEl) prepEl.classList.remove("show");
  if (typeof quizReset === "function") quizReset();
}

/* ===================== تشخيص (يُطلب من نافذة الإضافة) ===================== */
chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg && msg.type === "testLocal") {                         // اختبار مترجم Chrome المدمج
    (async () => {
      const out = { supported: typeof Translator !== "undefined", needsClick: svc.needsClick,
                    activation: !!(navigator.userActivation && navigator.userActivation.isActive) };
      if (out.supported) {
        try { out.availability = await Translator.availability({ sourceLanguage: "en", targetLanguage: "ar" }); }
        catch (e) { out.error = String((e && e.message) || e); }
      }
      send(out);
    })();
    return true;
  }
  if (!msg || msg.type !== "diag") return;
  const trs = {};
  Object.keys(tracks).forEach((k) => (trs[k] = { state: tracks[k].state, chunks: tracks[k].chunks.length }));
  const preps = {};
  prepMap.forEach((p, k) => {
    if (!srcKey || !k.startsWith(srcKey + "|")) return;
    let ok = 0, bad = 0;
    for (let i = 0; i < p.n; i++) { if (p.st[i] === 2) ok++; else if (p.st[i] === 3) bad++; }
    preps[p.code] = `${ok}/${p.n}` + (bad ? ` (failed ${bad})` : "");
  });
  send({
    version: chrome.runtime.getManifest().version,
    videoId: curVideoId(),
    enabled: settings.enabled,
    boxInPage: !!(box && box.isConnected),
    captured: !!baseUrl,
    srcLang: srcKey ? srcLang() : null,
    ccTries, domMode, tracks: trs, prep: preps,
    smartTr: settings.smartTr, provider: settings.provider, providerError: lastProviderError, blocked: Math.max(0, Math.ceil((svc.until - Date.now()) / 1000)),
    shortcuts: settings.shortcuts && settings.enabled,
    tts: "speechSynthesis" in window,
    voices: "speechSynthesis" in window ? speechSynthesis.getVoices().length : 0
  });
});

document.addEventListener("yt-navigate-start", reset);
loadSettings(() => setInterval(tick, 100));
