(() => {
  /* ---- التقاط رابط ملف الترجمة من طلب المشغل ---- */
  const isTT = (u) => typeof u === "string" && u.includes("/api/timedtext");
  const post = (u) => {
    try { window.postMessage({ source: "dsub", type: "track", url: new URL(u, location.href).href }, "*"); } catch (e) {}
  };
  const _fetch = window.fetch;
  window.fetch = function (...a) {
    try { const u = typeof a[0] === "string" ? a[0] : a[0] && a[0].url; if (isTT(u)) post(u); } catch (e) {}
    return _fetch.apply(this, a);
  };
  const _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, u, ...r) {
    try { if (isTT(String(u))) post(String(u)); } catch (e) {}
    return _open.call(this, m, u, ...r);
  };

  /* ---- اعتراض الاختصارات قبل يوتيوب (نسجّل مبكراً في مرحلة capture) ---- */
  let codes = [];
  const typing = (t) => t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
  const intercept = (e) => {
    if (!codes.length || !codes.includes(e.code)) return;
    if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
    if (typing(e.target) || !location.pathname.startsWith("/watch")) return;
    e.preventDefault();
    e.stopImmediatePropagation();                 // يمنع يوتيوب من تنفيذ اختصاره (مثل F = شاشة كاملة)
    if (e.type === "keydown" && !e.repeat) window.postMessage({ source: "dsub-key", code: e.code }, "*");
  };
  ["keydown", "keypress", "keyup"].forEach((t) => window.addEventListener(t, intercept, true));

  /* ---- أوامر من سكربت الإضافة ---- */
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.source !== "dsub-cmd") return;
    if (e.data.type === "keys") { codes = Array.isArray(e.data.codes) ? e.data.codes : []; return; }
    if (e.data.type !== "ensureCC") return;
    const p = document.getElementById("movie_player");
    if (!p) return;
    try {
      const on = p.isSubtitlesOn && p.isSubtitlesOn();
      if (!on) { p.toggleSubtitlesOn && p.toggleSubtitlesOn(); }
      else if (e.data.force && p.toggleSubtitles) {
        p.toggleSubtitles();
        setTimeout(() => p.toggleSubtitlesOn && p.toggleSubtitlesOn(), 350);
      }
    } catch (_) {}
  });
})();
