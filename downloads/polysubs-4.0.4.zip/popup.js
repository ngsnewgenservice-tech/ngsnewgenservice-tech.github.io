const DEFAULT_KEYS = {
  prev: "KeyA", next: "KeyD", repeat: "KeyS", loop: "KeyR", speak: "KeyW",
  save: "KeyB", hideTrans: "KeyH", original: "KeyO", quiz: "KeyQ", autoPause: "KeyP", quizNow: "KeyG"
};
const DEFAULTS = {
  enabled: true, showOriginal: true, hideTrans: false, quiz: false,
  origSize: 22, origColor: "#ffffff", bgOpacity: 0.6, width: 70, autoShrink: true, autoScale: true,
  font: "system", weight: 600, pos: null, autoPause: false, pauseOnLookup: true,
  autoRead: "off", ttsMode: "smart", ttsRate: 1, duck: true,
  shortcuts: true, keys: DEFAULT_KEYS,
  autoPunct: true, pauseScale: 1, voices: {}, origLang: "en",
  smartTr: true, provider: "google", dialect: "msa",
  models: { claude: "claude-haiku-5-5", openai: "" }, llmBase: "https://api.openai.com/v1",
  langs: [{ code: "ar", size: 22, color: "#ffd54a" }],
  uiLang: "", quizAuto: true, quizButton: true, quizCount: 10, quizPlace: "overlay",
  quizLangs: [], quizTypes: ["mcq", "reverse", "blank", "listen", "order", "speak"]
};
const FONTS = {
  system: '"Inter","Segoe UI",system-ui,Tahoma,sans-serif', serif: 'Georgia,"Times New Roman",serif',
  rounded: '"Nunito","Varela Round","Segoe UI",sans-serif', mono: 'ui-monospace,Consolas,monospace'
};
/* Languages available for subtitles (native names). */
const LANGS = [
  ["ar","العربية"],["en","English"],["fr","Français"],["es","Español"],["de","Deutsch"],
  ["it","Italiano"],["pt","Português"],["ru","Русский"],["tr","Türkçe"],["nl","Nederlands"],
  ["ja","日本語"],["ko","한국어"],["zh-CN","中文"],["hi","हिन्दी"],["id","Bahasa Indonesia"],
  ["pl","Polski"],["uk","Українська"],["vi","Tiếng Việt"],["th","ไทย"],["fa","فارسی"],["ur","اردو"],["bn","বাংলা"],["sv","Svenska"]
];
const SAMPLES = {
  ar: "كيف حالك اليوم؟", en: "How are you today?", fr: "Comment vas-tu aujourd'hui ?",
  es: "¿Cómo estás hoy?", de: "Wie geht es dir heute?", it: "Come stai oggi?",
  pt: "Como você está hoje?", ru: "Как ты сегодня?", tr: "Bugün nasılsın?",
  nl: "Hoe gaat het vandaag?", ja: "今日は元気ですか？", ko: "오늘 어떠세요?",
  "zh-CN": "你今天好吗？", hi: "आज आप कैसे हैं?", id: "Apa kabar hari ini?"
};
const PRESETS = {
  beginner: { showOriginal: true, hideTrans: false, quiz: false, autoPause: false, origSize: 24 },
  mid:      { showOriginal: true, hideTrans: false, quiz: true,  autoPause: false },
  adv:      { showOriginal: true, hideTrans: true,  quiz: false, autoPause: true }
};
const ACTIONS = ["prev", "next", "repeat", "loop", "speak", "save", "hideTrans", "original", "quiz", "autoPause", "quizNow"];
const YT_KEYS = ["KeyF", "KeyT", "KeyI", "KeyM", "KeyK", "KeyJ", "KeyL", "KeyC", "Space"];
const COLORS = ["#ffd54a", "#7CFC9A", "#6EC6FF", "#FF9AA2", "#C3A6FF", "#FFB86B", "#5EEAD4", "#F9A8D4"];
const nameOf = (c) => (LANGS.find((l) => l[0] === c) || [c, c])[1];
const $ = (id) => document.getElementById(id);
let s = JSON.parse(JSON.stringify(DEFAULTS));
let license = null;
const save = (patch) => chrome.storage.sync.set(patch);
const UI = () => psUiLang(s.uiLang);
const t = (k, v) => psT(UI(), k, v);
const lim = () => psLimits(license);

/* ---- interface language ---- */
function applyI18n() {
  const l = UI();
  document.documentElement.lang = l;
  document.documentElement.dir = PS_RTL.includes(l) ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach((e) => { e.textContent = t(e.dataset.i18n); });
  document.querySelectorAll("[data-i18n-ph]").forEach((e) => { e.placeholder = t(e.dataset.i18nPh); });
}
PS_UI_LANGS.forEach(([c, n]) => { const o = document.createElement("option"); o.value = c; o.textContent = n; $("uiLang").appendChild(o); });
$("uiLang").onchange = () => {
  s.uiLang = $("uiLang").value; save({ uiLang: s.uiLang });
  applyI18n(); renderLangs(); renderKeys(); renderQuizTab(); renderPlan(); syncAll();
};

/* ---- tabs ---- */
document.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => {
  document.querySelectorAll(".tabs button, .tab").forEach((x) => x.classList.remove("on"));
  b.classList.add("on"); $(b.dataset.tab).classList.add("on");
  if (b.dataset.tab === "t4") renderDict();
  if (b.dataset.tab === "t6") renderQuizTab();
}));
const showTab = (id) => document.querySelector(`.tabs button[data-tab="${id}"]`).click();

LANGS.forEach(([c, n]) => { const o = document.createElement("option"); o.value = c; o.textContent = n; $("origLang").appendChild(o); });

/* ---- bound fields ---- */
const fmt = (key, v) => key === "bgOpacity" ? Math.round(v * 100) + "%" : key === "width" ? v + "%" : (key === "ttsRate" || key === "pauseScale") ? v + "×" : v;
function sync(el) {
  const key = el.dataset.key;
  if (el.type === "checkbox") el.checked = !!s[key]; else el.value = s[key];
  const em = el.parentElement.querySelector("em");
  if (em && el.type === "range") em.textContent = fmt(key, s[key]);
}
const bound = [...document.querySelectorAll("[data-key]")];
bound.forEach((el) => el.addEventListener("input", () => {
  const key = el.dataset.key;
  const v = el.type === "checkbox" ? el.checked : (el.type === "range" || el.dataset.num) ? Number(el.value) : el.value;
  s[key] = v; save({ [key]: v }); sync(el); renderPreview();
  if (key === "origLang") renderVoices();
  if (key === "provider") renderLLM();
}));
const syncAll = () => bound.forEach(sync);

document.querySelectorAll("[data-preset]").forEach((b) => b.addEventListener("click", () => {
  Object.assign(s, PRESETS[b.dataset.preset]); save(PRESETS[b.dataset.preset]); syncAll(); renderPreview();
}));

/* ---- preview + translation languages ---- */
function renderPreview() {
  const k = 0.7;
  const pv = document.createElement("div");
  pv.className = "pv";
  pv.style.background = `rgba(10,10,18,${s.bgOpacity})`;
  pv.style.fontFamily = FONTS[s.font] || FONTS.system;
  pv.style.fontWeight = s.weight;
  const add = (text, size, color, blur) => {
    const l = document.createElement("span");
    l.className = "pv-line"; l.dir = "auto"; l.textContent = text;
    l.style.fontSize = Math.round(size * k) + "px"; l.style.color = color;
    if (blur) l.style.filter = "blur(4px)";
    pv.appendChild(l);
  };
  if (s.showOriginal) add("How are you today?", s.origSize, s.origColor);
  if (!s.hideTrans) s.langs.slice(0, lim().maxLangs).forEach((l) => add(SAMPLES[l.code] || "…", l.size, l.color, s.quiz));
  const box = $("preview"); box.textContent = ""; box.appendChild(pv);
}

function renderLangs() {
  const wrap = $("langs");
  wrap.textContent = "";
  const max = lim().maxLangs;
  s.langs.forEach((l, i) => {
    const d = document.createElement("div");
    d.className = "lang" + (i >= max ? " locked" : "");
    const top = document.createElement("div"); top.className = "lang-top";
    const dot = document.createElement("span"); dot.className = "dot"; dot.style.background = l.color;
    const name = document.createElement("b"); name.textContent = nameOf(l.code) + (i >= max ? " 🔒" : "");
    const rm = document.createElement("button"); rm.className = "icon-btn"; rm.title = t("remove"); rm.textContent = "✕";
    rm.onclick = () => { s.langs.splice(i, 1); save({ langs: s.langs }); renderLangs(); };
    top.append(dot, name, rm);
    const f1 = document.createElement("div"); f1.className = "field";
    f1.innerHTML = `<span></span><input type="range" min="12" max="48"><em></em>`;
    f1.querySelector("span").textContent = t("size");
    const rng = f1.querySelector("input"); rng.value = l.size; f1.querySelector("em").textContent = l.size;
    rng.oninput = (e) => { l.size = Number(e.target.value); f1.querySelector("em").textContent = l.size; save({ langs: s.langs }); renderPreview(); };
    const f2 = document.createElement("div"); f2.className = "field";
    f2.innerHTML = `<span></span><input type="color">`;
    f2.querySelector("span").textContent = t("color");
    const col = f2.querySelector("input"); col.value = l.color;
    col.oninput = (e) => { l.color = e.target.value; dot.style.background = l.color; save({ langs: s.langs }); renderPreview(); };
    d.append(top, f1, f2);
    wrap.appendChild(d);
  });
  const sel = $("newLang");
  sel.textContent = "";
  LANGS.filter((x) => !s.langs.some((l) => l.code === x[0])).forEach((x) => {
    const o = document.createElement("option"); o.value = x[0]; o.textContent = x[1]; sel.appendChild(o);
  });
  const full = s.langs.length >= max;
  $("addLang").disabled = full || !sel.options.length;
  $("count").textContent = `${Math.min(s.langs.length, max)} / ${max}`;
  const ll = $("langLimit");
  ll.hidden = !(full && !psIsPro(license));
  if (!ll.hidden) {
    ll.textContent = "";
    const sp = document.createElement("span"); sp.textContent = "⭐ " + t("lang_limit_free", { n: max });
    const b = document.createElement("button"); b.textContent = t("q_upgrade"); b.onclick = () => showTab("t7");
    ll.append(sp, b);
  }
  renderPreview();
  renderVoices();
}
$("addLang").onclick = () => {
  const code = $("newLang").value;
  if (!code || s.langs.length >= lim().maxLangs) return;
  s.langs.push({ code, size: 22, color: COLORS[s.langs.length % COLORS.length] });
  save({ langs: s.langs }); renderLangs();
};
$("resetPos").onclick = () => save({ pos: null });

/* ---- translation provider ---- */
function renderLLM() {
  const llm = s.provider === "claude" || s.provider === "openai";
  $("llmBox").style.display = llm ? "block" : "none";
  $("baseRow").style.display = s.provider === "openai" ? "flex" : "none";
  $("llmModel").value = (s.models && s.models[s.provider]) || "";
  $("llmBase").value = s.llmBase || "";
}
chrome.storage.local.get({ llmKey: "" }, ({ llmKey }) => { $("llmKey").value = llmKey; });
$("llmKey").oninput = () => chrome.storage.local.set({ llmKey: $("llmKey").value.trim() });   // key stays on this device (not synced)
$("llmModel").oninput = () => {
  s.models = Object.assign({}, s.models, { [s.provider]: $("llmModel").value.trim() });
  save({ models: s.models });
};
$("llmBase").onchange = () => {
  s.llmBase = $("llmBase").value.trim(); save({ llmBase: s.llmBase });
  try { chrome.permissions.request({ origins: [new URL(s.llmBase).origin + "/*"] }); } catch (_) {}
};

/* ---- voices ---- */
function renderVoices() {
  const wrap = $("voiceList");
  if (!wrap || !("speechSynthesis" in window)) return;
  wrap.textContent = "";
  const voices = speechSynthesis.getVoices();
  const bases = [...new Set([s.origLang, ...s.langs.map((l) => l.code)].map((c) => c.split("-")[0]))];
  bases.forEach((base) => {
    const info = LANGS.find((l) => l[0].split("-")[0] === base) || [base, base];
    const cands = voices.filter((v) => v.lang.replace("_", "-").toLowerCase().split("-")[0] === base);
    const row = document.createElement("div"); row.className = "field voice-row";
    const lab = document.createElement("span"); lab.textContent = t("voice_of", { x: info[1] });
    row.appendChild(lab);
    if (!cands.length) {
      const e = document.createElement("em"); e.textContent = t("no_voice"); row.appendChild(e);
      wrap.appendChild(row); return;
    }
    const sel = document.createElement("select");
    const auto = document.createElement("option"); auto.value = ""; auto.textContent = t("auto_best"); sel.appendChild(auto);
    cands.forEach((v) => {
      const o = document.createElement("option"); o.value = v.name;
      o.textContent = v.name + (v.localService ? "" : " ☁"); sel.appendChild(o);
    });
    sel.value = (s.voices && s.voices[base]) || "";
    sel.onchange = () => {
      s.voices = Object.assign({}, s.voices);
      if (sel.value) s.voices[base] = sel.value; else delete s.voices[base];
      save({ voices: s.voices });
    };
    const play = document.createElement("button"); play.className = "icon-btn"; play.textContent = "▶"; play.title = t("try_voice");
    play.onclick = () => {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(SAMPLES[info[0]] || "Hello, how are you today?");
      u.lang = cands[0].lang;
      u.voice = cands.find((x) => x.name === sel.value) || cands[0]; speechSynthesis.speak(u);
    };
    row.append(sel, play); wrap.appendChild(row);
  });
}
if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = renderVoices;

/* ---- shortcut editor ---- */
const keyName = (c) => !c ? "—" : c.replace(/^Key/, "").replace(/^Digit/, "").replace(/^Numpad/, "Num ").replace(/^Arrow/, "").replace("Bracket", "");
function renderKeys() {
  const list = $("keyList");
  list.textContent = "";
  ACTIONS.forEach((id) => {
    const row = document.createElement("div"); row.className = "keyrow";
    const name = document.createElement("span"); name.textContent = t("a_" + id);
    const btn = document.createElement("button"); btn.className = "keybtn"; btn.textContent = keyName(s.keys[id]);
    row.append(name, btn);
    if (YT_KEYS.includes(s.keys[id])) {
      const w = document.createElement("span"); w.className = "warn"; w.textContent = t("yt_uses");
      row.insertBefore(w, btn);
    }
    btn.onclick = () => {
      btn.textContent = t("press_key"); btn.classList.add("rec");
      const h = (e) => {
        e.preventDefault(); e.stopPropagation();
        if (/^(Shift|Control|Alt|Meta)/.test(e.code)) return;
        document.removeEventListener("keydown", h, true);
        if (e.code === "Escape") { renderKeys(); return; }
        if (e.code === "Backspace" || e.code === "Delete") s.keys[id] = "";
        else {
          const other = Object.keys(s.keys).find((k) => k !== id && s.keys[k] === e.code);
          if (other) s.keys[other] = "";
          s.keys[id] = e.code;
        }
        save({ keys: s.keys }); renderKeys();
      };
      document.addEventListener("keydown", h, true);
    };
    list.appendChild(row);
  });
}
$("resetKeys").onclick = () => { s.keys = Object.assign({}, DEFAULT_KEYS); save({ keys: s.keys }); renderKeys(); };

/* ---- quiz tab ---- */
function renderQuizTab() {
  const max = lim().quizMax;
  const qc = $("quizCount");
  qc.value = Math.min(s.quizCount, 30);
  const showCount = () => { $("quizCountVal").textContent = Math.min(s.quizCount, max) + (s.quizCount > max ? " 🔒" : ""); };
  showCount();
  qc.oninput = () => { s.quizCount = Number(qc.value); save({ quizCount: s.quizCount }); showCount(); };

  const ql = $("quizLangs"); ql.textContent = "";
  const choices = s.langs.slice(0, lim().maxLangs).map((l) => l.code);
  if (!choices.length) { const e = document.createElement("small"); e.textContent = t("no_tr_langs"); ql.appendChild(e); }
  let sel = (s.quizLangs || []).filter((c) => choices.includes(c));
  if (!sel.length && choices.length) sel = [choices[0]];
  choices.forEach((c) => {
    const b = document.createElement("button"); b.className = "chip" + (sel.includes(c) ? " on" : ""); b.textContent = nameOf(c);
    b.onclick = () => {
      if (sel.includes(c)) { if (sel.length > 1) sel = sel.filter((x) => x !== c); } else sel.push(c);
      s.quizLangs = sel.slice(); save({ quizLangs: s.quizLangs }); renderQuizTab();
    };
    ql.appendChild(b);
  });

  const qt = $("quizTypes"); qt.textContent = "";
  const allowed = lim().types;
  PS_QUIZ_TYPES.forEach((type) => {
    const row = document.createElement("div"); row.className = "field";
    const lab = document.createElement("span"); lab.textContent = t("qt_" + type);
    row.appendChild(lab);
    if (!allowed.includes(type)) {
      const tag = document.createElement("button"); tag.className = "pro-tag"; tag.textContent = "🔒 " + t("pro_tag");
      tag.onclick = () => showTab("t7");
      row.appendChild(tag);
    } else {
      const sw = document.createElement("label"); sw.className = "switch sm";
      const inp = document.createElement("input"); inp.type = "checkbox"; inp.checked = s.quizTypes.includes(type);
      inp.onchange = () => {
        const set = new Set(s.quizTypes);
        if (inp.checked) set.add(type); else set.delete(type);
        if (!PS_QUIZ_TYPES.some((x) => set.has(x) && allowed.includes(x))) { inp.checked = true; return; }   // keep at least one
        s.quizTypes = PS_QUIZ_TYPES.filter((x) => set.has(x)); save({ quizTypes: s.quizTypes });
      };
      sw.append(inp, document.createElement("span"));
      row.appendChild(sw);
    }
    qt.appendChild(row);
  });

  chrome.storage.local.get({ progress: {}, quizHistory: [] }, ({ progress, quizHistory }) => {
    const ps = Object.values(progress);
    const seen = ps.reduce((a, p) => a + p.seen, 0), correct = ps.reduce((a, p) => a + p.correct, 0);
    const stats = [
      [t("st_quizzes"), quizHistory.length],
      [t("st_words"), ps.length],
      [t("st_known"), ps.filter((p) => p.box >= 3).length],
      [t("st_acc"), seen ? Math.round((correct / seen) * 100) + "%" : "—"]
    ];
    const st = $("stats"); st.textContent = "";
    stats.forEach(([k, v]) => {
      const d = document.createElement("div"); d.className = "stat";
      const b = document.createElement("b"); b.textContent = v;
      const sp = document.createElement("span"); sp.textContent = k;
      d.append(b, sp); st.appendChild(d);
    });
  });
}

/* ---- saved words ---- */
function renderDict() {
  chrome.storage.local.get({ dict: [] }, ({ dict }) => {
    const max = lim().maxWords;
    $("dictCount").textContent = isFinite(max) ? t("word_limit", { n: dict.length, max }) : t("items", { n: dict.length });
    const list = $("dictList");
    list.textContent = "";
    if (!dict.length) {
      const e = document.createElement("div"); e.className = "empty"; e.textContent = t("no_words");
      list.appendChild(e); return;
    }
    dict.slice(-8).reverse().forEach((d) => {
      const row = document.createElement("div"); row.className = "dict-item";
      const w = document.createElement("span"); w.className = "w"; w.dir = "auto"; w.textContent = d.word;
      const tr = document.createElement("span"); tr.className = "t"; tr.dir = "auto";
      tr.textContent = Object.values(d.translations || {})[0] || d.sentenceTr || "";
      const x = document.createElement("button"); x.className = "icon-btn"; x.textContent = "✕"; x.title = t("remove");
      x.onclick = () => chrome.storage.local.set({ dict: dict.filter((y) => y !== d) }, renderDict);
      row.append(w, tr, x); list.appendChild(row);
    });
  });
}
const csvCell = (v) => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
$("exportCsv").onclick = () => {
  chrome.storage.local.get({ dict: [] }, ({ dict }) => {
    if (!dict.length) return;
    const rows = [["Front", "Back", "Sentence", "SentenceTranslation", "Source"]];
    dict.forEach((d) => rows.push([
      d.word,
      Object.entries(d.translations || {}).map(([c, v]) => `${c}: ${v}`).join(" | ") || d.sentenceTr || "",
      d.sentence, d.sentenceTr,
      `https://www.youtube.com/watch?v=${d.videoId}&t=${d.time || 0}s`
    ]));
    const csv = "﻿" + rows.map((r) => r.map(csvCell).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    a.download = "polysubs-words.csv"; a.click();
  });
};
$("clearDict").onclick = () => {
  if (confirm(t("confirm_clear"))) chrome.storage.local.set({ dict: [] }, renderDict);
};

/* ---- Premium ---- */
function renderPlan() {
  const pro = psIsPro(license);
  $("proBadge").hidden = !pro;
  $("planState").textContent = pro ? t("plan_pro") + (license.email ? " · " + license.email : "") : t("plan_free");
  $("planState").className = "plan-state " + (pro ? "on" : "");
  $("getPro").hidden = pro;
  $("proNote").textContent = !pro && !PS_CONFIG.checkoutUrl ? t("checkout_soon") : "";
  $("deactivate").hidden = !(license && license.key);
  if (license && license.key && !$("licKey").value) $("licKey").value = license.key.replace(/^(.{4}).*(.{4})$/, "$1••••••••$2");
}
$("getPro").onclick = () => chrome.tabs.create({ url: PS_CONFIG.checkoutUrl || PS_CONFIG.website + "/#pricing" });
const licMsg = (txt, ok) => { $("licMsg").textContent = txt; $("licMsg").className = "lic-msg " + (ok ? "ok" : ok === false ? "bad" : ""); };
$("activate").onclick = () => {
  const key = $("licKey").value.trim();
  if (!key || key.includes("••")) return;
  licMsg(t("checking"));
  $("activate").disabled = true;
  chrome.runtime.sendMessage({ type: "licenseActivate", key, device: navigator.platform || "Chrome" }, (r) => {
    $("activate").disabled = false;
    if (chrome.runtime.lastError || !r) { licMsg(t("act_fail", { x: t("lic_net") }), false); return; }
    if (r.ok) { license = r.license; licMsg(t("act_ok"), true); refreshAll(); return; }
    const why = { invalid: t("lic_invalid"), wrong_product: t("lic_wrong_product"), inactive: t("lic_inactive"), net: t("lic_net") }[r.reason] || r.detail || "";
    licMsg(t("act_fail", { x: why }), false);
  });
};
$("deactivate").onclick = () => {
  chrome.runtime.sendMessage({ type: "licenseDeactivate" }, () => {
    void chrome.runtime.lastError;
    license = null; $("licKey").value = ""; licMsg(""); refreshAll();
  });
};

/* ---- diagnostics (technical, shown in English) ---- */
let lastReport = "";
$("runDiag").onclick = () => {
  const out = $("diagOut");
  out.textContent = "";
  $("copyDiag").style.display = "none";
  const note = (txt) => { const n = document.createElement("div"); n.className = "diag-note"; n.textContent = txt; out.appendChild(n); };
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return note("No active tab.");
    chrome.tabs.sendMessage(tabs[0].id, { type: "diag" }, (r) => {
      if (chrome.runtime.lastError || !r) {
        return note("PolySubs isn't running in this tab. Open a video on youtube.com, refresh the page (Ctrl+Shift+R) and check again.");
      }
      lastReport = JSON.stringify(r, null, 2);
      const row = (ok, label, extra) => {
        const d = document.createElement("div"); d.className = "diag-row";
        const a = document.createElement("span"); a.textContent = ok === null ? "➖" : ok ? "✅" : "❌";
        const b = document.createElement("b"); b.textContent = label;
        const e = document.createElement("em"); e.textContent = extra || "";
        d.append(a, b, e); out.appendChild(d);
      };
      row(r.enabled, "Extension on");
      row(r.boxInPage, "Subtitle box on the page");
      row(r.captured, "YouTube subtitles captured", r.captured ? "Video language: " + r.srcLang : `CC attempts: ${r.ccTries}`);
      Object.entries(r.tracks).forEach(([k, v]) =>
        row(v.state === "ok", "Subtitle file: " + (k === "orig" ? "original" : k), v.state === "ok" ? v.chunks + " sentences" : v.state));
      Object.entries(r.prep).forEach(([k, v]) => row(null, "Pre-translated: " + k, v));
      row(r.domMode ? null : true, "Mode", r.domMode ? "Fallback (reading from screen)" : "Normal");
      row(r.smartTr, "Smart sentence translation", "Provider: " + r.provider);
      if (r.providerError) row(false, "Last provider error", r.providerError);
      if (r.blocked > 0) row(false, "Google paused requests", `ends in ${r.blocked}s`);
      row(r.shortcuts, "Shortcuts on");
      row(r.tts && r.voices > 0, "Voices available", String(r.voices));
      if (!r.captured && r.ccTries >= 6 && !r.domMode)
        note("No subtitles appeared for this video. Try a video with subtitles (for example a TED talk) or press the CC button once yourself.");
      $("copyDiag").style.display = "block";
    });
  });
};
$("testTr").onclick = () => {
  const out = $("diagOut");
  out.textContent = "…";
  chrome.runtime.sendMessage({ type: "test" }, (r) => {
    out.textContent = "";
    const row = (ok, label, extra) => {
      const d = document.createElement("div"); d.className = "diag-row";
      const a = document.createElement("span"); a.textContent = ok ? "✅" : "❌";
      const b = document.createElement("b"); b.textContent = label;
      const e = document.createElement("em"); e.textContent = extra || "";
      d.append(a, b, e); out.appendChild(d);
    };
    if (chrome.runtime.lastError || !r) { row(false, "Background service", (chrome.runtime.lastError || {}).message || "No reply"); return; }
    row(r.google.ok, "Google (free)", r.google.ok ? `${r.google.text} — ${r.google.ms}ms` : r.google.error);
    if (r.blocked > 0) row(false, "Google temporarily limited", `ends in ${r.blocked}s`);
    if (r.provider === "chrome") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0]) return;
        chrome.tabs.sendMessage(tabs[0].id, { type: "testLocal" }, (l) => {
          if (chrome.runtime.lastError || !l) return row(false, "Chrome built-in translator", "Open a YouTube video first");
          const ok = l.supported && l.availability && l.availability !== "unavailable";
          row(ok, "Chrome built-in translator", !l.supported ? "Not available (needs desktop Chrome 138+)"
              : `en→ar: ${l.availability || l.error}` + (l.needsClick ? " — needs a click on the page" : ""));
        });
      });
    }
    if (r.llm) row(r.llm.ok, "Provider: " + r.provider, r.llm.ok ? `${r.llm.text} — ${r.llm.ms}ms` : r.llm.error);
  });
};
$("copyDiag").onclick = () => { navigator.clipboard.writeText(lastReport); $("copyDiag").textContent = t("copied"); };

/* ---- start ---- */
function refreshAll() { renderPlan(); renderLangs(); renderQuizTab(); }
chrome.storage.sync.get(DEFAULTS, (stored) => {
  s = stored;
  s.keys = Object.assign({}, DEFAULT_KEYS, stored.keys || {});
  $("uiLang").value = UI();
  applyI18n();
  chrome.storage.local.get({ license: null }, (r) => {
    license = r.license;
    syncAll(); renderLangs(); renderKeys(); renderLLM(); renderQuizTab(); renderPlan();
    chrome.runtime.sendMessage({ type: "licenseValidate", force: false }, (v) => {
      void chrome.runtime.lastError;
      if (v && v.license !== undefined && JSON.stringify(v.license) !== JSON.stringify(license)) { license = v.license; refreshAll(); }
    });
  });
});
