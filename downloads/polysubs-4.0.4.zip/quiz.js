/* ===================== PolySubs — video quiz =====================
   Runs in the same content-script scope as content.js (uses tracks, settings, speak, getVideo, …). */
SEL.autonavCancel = ".ytp-autonav-endscreen-upnext-cancel-button";

const QZ = { root: null, video: null, onEnded: null, offeredFor: "", btn: null, resume: false,
             clipTimer: null, speakReq: "", speakCb: null, run: null };

const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const uiLang = () => psUiLang(settings.uiLang);
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
const normTxt = (s) => String(s || "").toLowerCase().normalize("NFKC").replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
const openUpgrade = () => window.open(PS_CONFIG.checkoutUrl || PS_CONFIG.website + "/#pricing", "_blank", "noopener");

/* ---------- hooks called from content.js ---------- */
function quizTick(video) {
  if (QZ.video !== video) {
    if (QZ.video && QZ.onEnded) QZ.video.removeEventListener("ended", QZ.onEnded);
    QZ.video = video;
    QZ.onEnded = onVideoEnded;
    video.addEventListener("ended", QZ.onEnded);
  }
  ensureQuizButton();
}
function quizReset() {
  quizClose(false);
  QZ.offeredFor = "";
}

function onVideoEnded() {
  if (!settings.enabled || !settings.quizAuto || QZ.root) return;
  if (player && player.classList.contains(SEL.adClass)) return;
  const vid = curVideoId(), ch = origChunks();
  if (!vid || QZ.offeredFor === vid || !ch || ch.length < 4) return;
  QZ.offeredFor = vid;
  setTimeout(() => { const b = document.querySelector(SEL.autonavCancel); if (b) b.click(); }, 400);   // stop autoplay of the next video
  quizOpen("end");
}

function ensureQuizButton() {
  if (!player) return;
  const show = settings.enabled && settings.quizButton && !player.classList.contains(SEL.adClass);
  if (!QZ.btn || !QZ.btn.isConnected) {
    QZ.btn = el("button", "ps-quiz-btn");
    QZ.btn.type = "button";
    stopEvents(QZ.btn, ["mousedown", "mouseup", "pointerdown", "pointerup", "dblclick"]);
    QZ.btn.addEventListener("click", (e) => { e.stopPropagation(); quizOpen("manual"); });
    player.appendChild(QZ.btn);
  }
  const label = "🎯 " + T("q_btn");
  if (QZ.btn.textContent !== label) QZ.btn.textContent = label;
  QZ.btn.style.display = show && !QZ.root ? "" : "none";
}

/* ---------- open / close ---------- */
function quizOpen(trigger) {
  if (QZ.root) { quizClose(true); return; }
  if (!ensureBox()) return;
  const v = getVideo();
  QZ.resume = false;
  if (trigger === "manual" && v && !v.paused) { v.pause(); QZ.resume = true; }
  closeLookup("drop");

  const side = settings.quizPlace === "side" && !document.fullscreenElement;
  const root = el("div", "ps-quiz " + (side ? "ps-side" : "ps-overlay"));
  root.dir = PS_RTL.includes(uiLang()) ? "rtl" : "ltr";
  root.lang = uiLang();
  stopEvents(root, ["click", "dblclick", "mousedown", "mouseup", "pointerdown", "pointerup", "touchstart", "wheel", "keydown", "keyup", "keypress"]);
  const card = el("div", "ps-card");
  const head = el("div", "ps-head");
  head.append(el("span", "ps-title", "🎯 " + T("q_title")));
  const x = el("button", "ps-x", "✕"); x.type = "button"; x.title = T("q_close"); x.onclick = () => quizClose(true);
  head.append(x);
  const body = el("div", "ps-body");
  card.append(head, body);
  root.append(card);
  (side ? document.body : player).appendChild(root);
  QZ.root = root; QZ.body = body;
  document.documentElement.classList.add("ps-quiz-open");
  ensureQuizButton();
  renderStart();
}

function quizClose(resume) {
  stopClip();
  QZ.speakReq = ""; QZ.speakCb = null; QZ.run = null;
  if (QZ.root) { QZ.root.remove(); QZ.root = null; }
  document.documentElement.classList.remove("ps-quiz-open");
  if (resume && QZ.resume) { const v = getVideo(); if (v && v.paused && !v.ended) v.play(); }
  QZ.resume = false;
  ensureQuizButton();
}
document.addEventListener("keydown", (e) => { if (e.code === "Escape" && QZ.root) quizClose(true); }, true);
document.addEventListener("fullscreenchange", () => {           // the side panel can't be seen in full screen
  if (QZ.root && QZ.root.classList.contains("ps-side") && document.fullscreenElement) quizClose(false);
});

/* ---------- start screen ---------- */
function quizLangChoices() {
  const src = baseLang(srcLang());
  return activeLangs().map((l) => l.code).filter((c) => baseLang(c) !== src);
}
function allowedTypes() {
  const lim = limits().types;
  const chosen = (settings.quizTypes || []).filter((t) => lim.includes(t));
  return chosen.length ? chosen : [lim[0]];
}

function renderStart() {
  const b = QZ.body; b.textContent = "";
  const ch = origChunks();
  if (!ch || ch.length < 4) { message(ch ? T("q_not_enough") : T("q_no_subs")); return; }
  const choices = quizLangChoices();
  if (!choices.length) { message(T("no_tr_langs")); return; }
  let sel = (settings.quizLangs || []).filter((c) => choices.includes(c));
  if (!sel.length) sel = [choices[0]];
  const count = Math.min(settings.quizCount || 10, limits().quizMax);

  b.append(el("h3", "ps-h", T("q_ready")));
  b.append(el("p", "ps-muted", T("q_from_video", { n: count })));
  b.append(el("div", "ps-label", T("q_lang")));
  const chips = el("div", "ps-chips");
  choices.forEach((c) => {
    const chip = el("button", "ps-chip" + (sel.includes(c) ? " on" : ""), psLangName(c, uiLang()));
    chip.type = "button";
    chip.onclick = () => {
      if (sel.includes(c)) { if (sel.length > 1) sel = sel.filter((x) => x !== c); }
      else sel.push(c);
      chips.querySelectorAll(".ps-chip").forEach((n, i) => n.classList.toggle("on", sel.includes(choices[i])));
      settings.quizLangs = sel.slice();
      chrome.storage.sync.set({ quizLangs: settings.quizLangs });
    };
    chips.append(chip);
  });
  b.append(chips);

  const types = allowedTypes();
  const tl = el("div", "ps-types");
  types.forEach((t) => tl.append(el("span", "ps-type", T("qt_" + t))));
  b.append(tl);
  if (!psIsPro(license)) {
    const up = el("div", "ps-upsell");
    up.append(el("span", "", "⭐ " + T("q_pro_more")));
    const ub = el("button", "ps-link", T("q_upgrade")); ub.type = "button"; ub.onclick = openUpgrade;
    up.append(ub); b.append(up);
  }
  const row = el("div", "ps-row");
  const later = el("button", "ps-btn ghost", T("q_later")); later.type = "button"; later.onclick = () => quizClose(true);
  const go = el("button", "ps-btn primary", T("q_start")); go.type = "button";
  go.onclick = () => startQuiz(sel.slice(), count, types);
  row.append(later, go); b.append(row);
}

function message(text) {
  const b = QZ.body; b.textContent = "";
  b.append(el("p", "ps-msg", text));
  const row = el("div", "ps-row");
  const c = el("button", "ps-btn primary", T("q_close")); c.type = "button"; c.onclick = () => quizClose(true);
  row.append(c); b.append(row);
}

/* ---------- building questions ---------- */
function tokenize(text) {
  const seg = getSegmenter(), out = [];
  if (seg) { for (const p of seg.segment(text)) if (p.isWordLike) out.push(p.segment); }
  else text.split(/\s+/).forEach((w) => { const c = w.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ""); if (c) out.push(c); });
  return out;
}
const isCJK = (code) => /^(zh|ja|ko|th)/.test(code);

function sendBg(msg, ms) {
  return new Promise((resolve) => {
    let done = false;
    const tm = setTimeout(() => { done = true; resolve(null); }, ms || 12000);
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        void chrome.runtime.lastError;
        if (done) return; clearTimeout(tm); resolve(r || null);
      });
    } catch (_) { clearTimeout(tm); resolve(null); }
  });
}
const meaningOf = async (word, to) => {
  const r = await sendBg({ type: "lookup", word, sentence: "", to });
  return r && r.main ? cleanCue(r.main) : "";
};
const translateText = async (text, to) => {
  const r = await sendBg({ type: "translate", text, to, src: srcLang() });
  return r && r.text ? cleanCue(r.text) : "";
};

const progKey = (lang, src, word) => lang + "|" + src + "|" + word.toLowerCase();
const loadLocal = (defs) => new Promise((r) => chrome.storage.local.get(defs, r));

async function buildQuestions(langs, count, types, onProgress) {
  const chunks = origChunks() || [];
  const src = baseLang(srcLang());
  const minLen = isCJK(src) ? 2 : 4;
  const { dict, progress } = await loadLocal({ dict: [], progress: {} });

  // Word statistics from the whole transcript
  const freq = new Map();
  chunks.forEach((c, ci) => {
    for (const w of tokenize(c.text)) {
      if (!/\p{L}/u.test(w) || /\d/.test(w)) continue;
      const k = w.toLowerCase();
      let e = freq.get(k);
      if (!e) { e = { w, k, n: 0, chunks: [] }; freq.set(k, e); }
      e.n++;
      if (e.chunks.length < 6) e.chunks.push(ci);
    }
  });
  const ranked = [...freq.values()].sort((a, b) => b.n - a.n);
  const skipTop = Math.min(30, Math.floor(ranked.length * 0.08));      // the most frequent words are mostly "the, and, of…"
  let pool = ranked.slice(skipTop).filter((e) => [...e.w].length >= minLen);
  if (pool.length < 8) pool = ranked.filter((e) => [...e.w].length >= Math.max(2, minLen - 1));
  const known = (e, lang) => { const p = progress[progKey(lang, src, e.k)]; return p && p.box >= 3; };

  // Saved words from this video come first
  const vid = curVideoId();
  const saved = dict.filter((d) => d.videoId === vid && d.word && tokenize(d.word).length === 1)
                    .map((d) => freq.get(d.word.toLowerCase())).filter(Boolean);
  const order = [...new Set([...saved, ...shuffle(pool)])];

  // Plan: spread the chosen types and languages over the questions
  const wordTypes = ["mcq", "reverse", "blank"];
  let plan = [];
  const tOrder = shuffle(types);
  for (let i = 0; i < count; i++) plan.push({ type: tOrder[i % tOrder.length], lang: langs[i % langs.length] });
  plan = shuffle(plan);

  // Sentences for sentence-based questions
  const wc = (c) => tokenize(c.text).length;
  const usedChunks = new Set();
  const pickChunk = (min, max) => {
    const c = shuffle(chunks.map((c, i) => i)).find((i) => !usedChunks.has(i) && wc(chunks[i]) >= min && wc(chunks[i]) <= max);
    if (c == null) return null;
    usedChunks.add(c); return chunks[c];
  };

  // Assign words to word-based questions, preferring words not yet known in that language
  const usedWords = new Set();
  const takeWord = (lang) => {
    const cand = order.filter((e) => !usedWords.has(e.k));
    const e = cand.find((x) => !known(x, lang)) || cand[0];
    if (e) usedWords.add(e.k);
    return e;
  };
  const items = [];
  for (const p of plan) {
    if (wordTypes.includes(p.type)) {
      const e = takeWord(p.lang);
      if (e) items.push(Object.assign({ entry: e }, p));
    } else {
      const c = p.type === "listen" ? pickChunk(4, 18) : p.type === "order" ? pickChunk(4, 9) : pickChunk(3, 12);
      if (c) items.push(Object.assign({ chunk: c }, p));
      else { const e = takeWord(p.lang); if (e) items.push({ type: "mcq", lang: p.lang, entry: e }); }
    }
  }

  // Translations we need: meanings for mcq/reverse targets + a few extra words per language for wrong options
  const needMeaning = new Map();                                    // lang -> Set of entries
  const want = (lang, e) => { if (!needMeaning.has(lang)) needMeaning.set(lang, new Set()); needMeaning.get(lang).add(e); };
  items.forEach((it) => { if (it.type === "mcq" || it.type === "reverse") want(it.lang, it.entry); });
  for (const [lang, set] of needMeaning) {
    const extra = order.filter((e) => !usedWords.has(e.k)).slice(0, 4);
    extra.forEach((e) => set.add(e));
  }
  const meanings = new Map();                                       // lang|k -> meaning
  const jobs = [];
  for (const [lang, set] of needMeaning) for (const e of set) jobs.push({ lang, e });
  items.forEach((it) => { if (it.type === "blank" || it.type === "order") jobs.push({ hint: it }); });
  let done = 0;
  await Promise.all(jobs.map(async (j) => {
    if (j.hint) {
      const it = j.hint;
      if (it.type === "blank") {
        const ci = it.entry.chunks.find((i) => wc(chunks[i]) >= 4) ?? it.entry.chunks[0];
        it.chunk = chunks[ci];
      }
      it.hint = it.chunk ? await translateText(it.chunk.text, it.lang) : "";
    } else {
      const m = await meaningOf(j.e.w, j.lang);
      if (m && normTxt(m) !== normTxt(j.e.w)) meanings.set(j.lang + "|" + j.e.k, m);
    }
    onProgress && onProgress(++done, jobs.length);
  }));

  // Turn items into questions
  const qs = [];
  const otherWords = (e, n) => shuffle(order.filter((x) => x.k !== e.k && Math.abs([...x.w].length - [...e.w].length) <= 4)).slice(0, n).map((x) => x.w);
  for (const it of items) {
    if (it.type === "mcq" || it.type === "reverse") {
      const m = meanings.get(it.lang + "|" + it.entry.k);
      if (!m) continue;
      if (it.type === "mcq") {
        const wrong = shuffle([...meanings.entries()].filter(([k, v]) => k.startsWith(it.lang + "|") && normTxt(v) !== normTxt(m)).map(([, v]) => v));
        const opts = [...new Set([m, ...wrong])].slice(0, 4);
        if (opts.length < 3) continue;
        qs.push({ type: "mcq", lang: it.lang, word: it.entry.w, meaning: m, prompt: it.entry.w, options: shuffle(opts), answer: m,
                  chunk: chunks[it.entry.chunks[0]] });
      } else {
        const opts = [...new Set([it.entry.w, ...otherWords(it.entry, 6)])].slice(0, 4);
        if (opts.length < 3) continue;
        qs.push({ type: "reverse", lang: it.lang, word: it.entry.w, meaning: m, prompt: m, options: shuffle(opts), answer: it.entry.w,
                  chunk: chunks[it.entry.chunks[0]] });
      }
    } else if (it.type === "blank") {
      if (!it.chunk) continue;
      const re = new RegExp("(^|[^\\p{L}\\p{N}])" + it.entry.w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?=$|[^\\p{L}\\p{N}])", "iu");
      if (!re.test(it.chunk.text) && !isCJK(src)) continue;
      const sentence = isCJK(src) ? it.chunk.text.replace(it.entry.w, "____") : it.chunk.text.replace(re, "$1____");
      const opts = [...new Set([it.entry.w, ...otherWords(it.entry, 6)])].slice(0, 4);
      if (opts.length < 3) continue;
      qs.push({ type: "blank", lang: it.lang, word: it.entry.w, sentence, hint: it.hint, options: shuffle(opts), answer: it.entry.w, chunk: it.chunk });
    } else if (it.type === "listen") {
      const others = shuffle(chunks.filter((c) => c !== it.chunk && normTxt(c.text) !== normTxt(it.chunk.text) && wc(c) >= 3)).slice(0, 3).map((c) => c.text);
      if (others.length < 2) continue;
      qs.push({ type: "listen", lang: it.lang, chunk: it.chunk, options: shuffle([it.chunk.text, ...others]), answer: it.chunk.text });
    } else if (it.type === "order") {
      const words = isCJK(src) ? tokenize(it.chunk.text) : it.chunk.text.split(/\s+/).filter(Boolean);
      if (words.length < 3) continue;
      let tiles = shuffle(words.map((w, i) => ({ w, i })));
      if (tiles.every((t, i) => t.i === i)) tiles = tiles.reverse();
      qs.push({ type: "order", lang: it.lang, chunk: it.chunk, words, tiles, hint: it.hint, answer: it.chunk.text });
    } else if (it.type === "speak") {
      qs.push({ type: "speak", lang: it.lang, chunk: it.chunk, text: it.chunk.text, answer: it.chunk.text });
    }
  }
  return qs;
}

async function startQuiz(langs, count, types) {
  const b = QZ.body; b.textContent = "";
  const p = el("p", "ps-msg", T("q_preparing"));
  const bar = el("div", "ps-bar"); const fill = el("span"); bar.append(fill);
  b.append(p, bar);
  const run = { langs, count, types, qs: [], i: 0, results: [] };
  QZ.run = run;
  const qs = await buildQuestions(langs, count, types, (d, n) => { fill.style.width = Math.round((d / n) * 100) + "%"; });
  if (QZ.run !== run) return;                                    // closed while preparing
  if (!qs.length) { message(T("q_not_enough")); return; }
  run.qs = qs;
  renderQuestion();
}

/* ---------- playing a question ---------- */
function stopClip() { if (QZ.clipTimer) { clearInterval(QZ.clipTimer); QZ.clipTimer = null; } }
function playClip(chunk) {
  const v = getVideo(); if (!v) return;
  stopClip();
  v.currentTime = chunk.start / 1000;
  v.play();
  QZ.clipTimer = setInterval(() => {
    if (!QZ.root || v.currentTime * 1000 >= chunk.end + 150) { v.pause(); stopClip(); }
  }, 80);
}

function renderQuestion() {
  const run = QZ.run, q = run.qs[run.i], b = QZ.body;
  stopClip();
  b.textContent = "";
  const top = el("div", "ps-progress");
  top.append(el("span", "", T("q_of", { i: run.i + 1, n: run.qs.length })), el("span", "ps-tag", T("qt_" + q.type)));
  const pbar = el("div", "ps-bar thin"); const pf = el("span"); pf.style.width = (run.i / run.qs.length) * 100 + "%"; pbar.append(pf);
  b.append(top, pbar);

  const fb = el("div", "ps-feedback");
  const next = el("button", "ps-btn primary", run.i + 1 < run.qs.length ? T("q_next") : T("q_finish"));
  next.type = "button"; next.style.display = "none";
  next.onclick = () => { run.i++; if (run.i < run.qs.length) renderQuestion(); else renderResults(); };
  const skip = el("button", "ps-btn ghost", T("q_skip")); skip.type = "button";
  skip.onclick = () => finish(false, true);

  let answered = false;
  function finish(correct, skipped, extra) {
    if (answered) return;
    answered = true;
    stopClip();
    run.results.push(Object.assign({ q, correct: !!correct, skipped: !!skipped }, extra || {}));
    if (!skipped) {
      fb.textContent = correct ? T("q_correct") : T("q_wrong", { x: q.type === "mcq" ? q.answer : q.answer });
      fb.className = "ps-feedback " + (correct ? "ok" : "bad");
    }
    skip.style.display = "none"; next.style.display = "";
    if (skipped) next.click();
  }
  const choose = (opts, answer, onPick, optDir) => {
    const list = el("div", "ps-opts");
    opts.forEach((o) => {
      const btn = el("button", "ps-opt", o); btn.type = "button"; btn.dir = optDir || "auto";
      btn.onclick = () => {
        if (answered) return;
        const ok = o === answer;
        list.querySelectorAll(".ps-opt").forEach((n) => { n.disabled = true; if (n.textContent === answer) n.classList.add("ok"); });
        if (!ok) btn.classList.add("bad");
        onPick && onPick(ok);
        finish(ok);
      };
      list.append(btn);
    });
    return list;
  };
  const hear = (text, lang) => { const h = el("button", "ps-icon", "🔊"); h.type = "button"; h.title = T("c_listen"); h.onclick = () => speak(text, lang); return h; };
  const langName = psLangName(q.lang, uiLang());

  if (q.type === "mcq") {
    b.append(el("p", "ps-ask", T("q_what_means", { x: langName })));
    const w = el("div", "ps-prompt"); w.dir = "auto"; w.append(el("span", "", q.prompt), hear(q.prompt, srcLang()));
    b.append(w, choose(q.options, q.answer));
  } else if (q.type === "reverse") {
    b.append(el("p", "ps-ask", T("q_which_word")));
    const w = el("div", "ps-prompt", q.prompt); w.dir = "auto";
    b.append(w, choose(q.options, q.answer));
  } else if (q.type === "blank") {
    b.append(el("p", "ps-ask", T("q_fill")));
    const s = el("div", "ps-sentence", q.sentence); s.dir = "auto"; b.append(s);
    if (q.hint) { const h = el("div", "ps-hint", q.hint); h.dir = "auto"; b.append(h); }
    b.append(choose(q.options, q.answer));
  } else if (q.type === "listen") {
    b.append(el("p", "ps-ask", T("q_listen")));
    const r = el("div", "ps-row start");
    const play = el("button", "ps-btn ghost", T("q_replay")); play.type = "button"; play.onclick = () => playClip(q.chunk);
    const tts = el("button", "ps-btn ghost", "🔊"); tts.type = "button"; tts.title = T("c_listen");
    tts.onclick = () => { stopClip(); const v = getVideo(); if (v) v.pause(); speak(q.chunk.text, srcLang()); };
    r.append(play, tts); b.append(r, choose(q.options, q.answer));
    setTimeout(() => { if (QZ.run === run && run.qs[run.i] === q) playClip(q.chunk); }, 250);
  } else if (q.type === "order") {
    b.append(el("p", "ps-ask", T("q_order")));
    if (q.hint) { const h = el("div", "ps-hint", q.hint); h.dir = "auto"; b.append(h); }
    const built = el("div", "ps-built"); built.dir = "auto";
    const bank = el("div", "ps-bank"); bank.dir = "auto";
    const picked = [];
    const draw = () => {
      built.textContent = ""; bank.textContent = "";
      picked.forEach((t, k) => { const x = el("button", "ps-tile on", t.w); x.type = "button"; x.onclick = () => { if (!answered) { picked.splice(k, 1); draw(); } }; built.append(x); });
      q.tiles.filter((t) => !picked.includes(t)).forEach((t) => { const x = el("button", "ps-tile", t.w); x.type = "button"; x.onclick = () => { if (!answered) { picked.push(t); draw(); } }; bank.append(x); });
    };
    draw();
    const r = el("div", "ps-row");
    const clear = el("button", "ps-btn ghost", T("q_clear")); clear.type = "button"; clear.onclick = () => { if (!answered) { picked.length = 0; draw(); } };
    const check = el("button", "ps-btn primary", T("q_check")); check.type = "button";
    check.onclick = () => {
      if (answered || picked.length !== q.tiles.length) return;
      const ok = normTxt(picked.map((t) => t.w).join(" ")) === normTxt(q.words.join(" "));
      built.classList.add(ok ? "ok" : "bad");
      clear.disabled = check.disabled = true;
      finish(ok);
    };
    r.append(clear, check);
    b.append(built, bank, r);
  } else if (q.type === "speak") {
    b.append(el("p", "ps-ask", T("q_speak")));
    const s = el("div", "ps-sentence"); s.dir = "auto"; s.append(el("span", "", q.text), hear(q.text, srcLang()));
    const mic = el("button", "ps-btn primary big", T("q_mic")); mic.type = "button";
    const note = el("p", "ps-muted small", T("q_mic_note"));
    const out = el("div", "ps-heard"); out.dir = "auto";
    mic.onclick = () => {
      const req = Math.random().toString(36).slice(2);
      QZ.speakReq = req;
      mic.disabled = true; note.textContent = T("q_waiting_mic");
      QZ.speakCb = (r) => {
        mic.disabled = false; note.textContent = T("q_mic_note");
        if (r.error === "na") { fb.textContent = T("q_speech_na"); fb.className = "ps-feedback"; setTimeout(() => finish(false, true), 1500); return; }
        if (r.error) return;                                     // window closed without a result
        out.textContent = T("q_you_said", { x: r.transcript }) + " · " + T("q_score", { n: r.score });
        finish(r.score >= 70, false, { score: r.score });
      };
      chrome.runtime.sendMessage({ type: "openSpeak", text: q.text, lang: srcLang(), ui: uiLang(), req }, () => void chrome.runtime.lastError);
    };
    b.append(s, mic, note, out);
  }
  const foot = el("div", "ps-row");
  foot.append(skip, next);
  b.append(fb, foot);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== "speakResult" || !QZ.speakReq || msg.req !== QZ.speakReq) return;
  const cb = QZ.speakCb;
  if (!msg.error || msg.error !== "closed") { QZ.speakReq = ""; QZ.speakCb = null; }
  if (cb) cb(msg);
});

/* ---------- results + saving progress ---------- */
async function saveResults(run) {
  const src = baseLang(srcLang());
  const { progress, dict, quizHistory } = await loadLocal({ progress: {}, dict: [], quizHistory: [] });
  const now = Date.now();
  const days = [0, 1, 2, 4, 8, 16];
  let added = 0;
  const max = limits().maxWords;
  for (const r of run.results) {
    if (r.skipped || !r.q.word) continue;
    const k = progKey(r.q.lang, src, r.q.word);
    const p = progress[k] || { id: psId(), word: r.q.word, src, lang: r.q.lang, meaning: "", seen: 0, correct: 0, wrong: 0, box: 0 };
    p.seen++; if (r.correct) p.correct++; else p.wrong++;
    p.box = r.correct ? Math.min(5, p.box + 1) : Math.max(0, p.box - 2);
    p.due = now + days[p.box] * 86400000;
    if (r.q.meaning) p.meaning = r.q.meaning;
    p.updatedAt = now;
    progress[k] = p;
    if (!r.correct && dict.length < max &&
        !dict.some((d) => d.word.toLowerCase() === r.q.word.toLowerCase() && d.videoId === curVideoId())) {
      dict.push({ id: psId(), word: r.q.word, translations: r.q.meaning ? { [r.q.lang]: r.q.meaning } : {},
                  sentence: r.q.chunk ? r.q.chunk.text : "", sentenceTr: "", videoId: curVideoId(),
                  time: r.q.chunk ? Math.floor(r.q.chunk.start / 1000) : 0, date: now, source: "quiz" });
      added++;
    }
  }
  const answered = run.results.filter((r) => !r.skipped);
  quizHistory.push({ id: psId(), videoId: curVideoId(), date: now, src, langs: run.langs, types: run.types,
                     total: answered.length, correct: answered.filter((r) => r.correct).length, updatedAt: now });
  while (quizHistory.length > 300) quizHistory.shift();
  await new Promise((r) => chrome.storage.local.set({ progress, dict, quizHistory }, r));
  return added;
}

async function renderResults() {
  const run = QZ.run, b = QZ.body;
  stopClip();
  b.textContent = "";
  const answered = run.results.filter((r) => !r.skipped);
  const c = answered.filter((r) => r.correct).length;
  const pct = answered.length ? Math.round((c / answered.length) * 100) : 0;
  b.append(el("h3", "ps-h", T("q_done")));
  const ring = el("div", "ps-score"); ring.style.setProperty("--p", pct);
  ring.append(el("b", "", pct + "%"));
  b.append(ring, el("p", "ps-msg", T("q_result", { c, n: answered.length })));
  const added = await saveResults(run);
  const wrong = answered.filter((r) => !r.correct);
  if (wrong.length) {
    b.append(el("div", "ps-label", T("q_mistakes")));
    const list = el("div", "ps-mistakes");
    wrong.forEach((r) => {
      const row = el("div", "ps-mistake");
      const a = el("span", "ps-m-q", r.q.type === "mcq" || r.q.type === "blank" ? r.q.word : r.q.type === "reverse" ? r.q.prompt : r.q.answer);
      a.dir = "auto"; row.append(a);
      if (r.q.type === "mcq" || r.q.type === "reverse" || r.q.type === "blank") {
        const m = el("span", "ps-m-a", r.q.type === "reverse" ? r.q.answer : (r.q.meaning || r.q.hint || ""));
        m.dir = "auto"; row.append(m);
      }
      list.append(row);
    });
    b.append(list);
    if (added) b.append(el("p", "ps-muted small", T("q_saved_mistakes")));
  }
  if (!psIsPro(license)) {
    const up = el("div", "ps-upsell");
    up.append(el("span", "", "⭐ " + T("q_pro_more")));
    const ub = el("button", "ps-link", T("q_upgrade")); ub.type = "button"; ub.onclick = openUpgrade;
    up.append(ub); b.append(up);
  }
  const row = el("div", "ps-row");
  const again = el("button", "ps-btn ghost", T("q_retry")); again.type = "button"; again.onclick = () => renderStart();
  const close = el("button", "ps-btn primary", T("q_close")); close.type = "button"; close.onclick = () => quizClose(true);
  row.append(again, close); b.append(row);
}
