/* Speaking practice window: listens with Chrome's speech recognition and scores how close the user was. */
const qs = new URLSearchParams(location.search);
const TEXT = qs.get("text") || "", LANG = qs.get("lang") || "en", UI = psUiLang(qs.get("ui"));
const TAB = qs.get("tab"), REQ = qs.get("req");
const t = (k, v) => psT(UI, k, v);
const $ = (id) => document.getElementById(id);

document.documentElement.lang = UI;
document.documentElement.dir = PS_RTL.includes(UI) ? "rtl" : "ltr";
$("title").textContent = t("sp_title");
$("sayLbl").textContent = t("sp_say");
$("target").textContent = TEXT;
$("start").textContent = t("sp_start");
$("again").textContent = t("sp_again");
$("use").textContent = t("sp_use");

const norm = (s) => s.toLowerCase().normalize("NFKC").replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
const tokens = (s) => {
  const n = norm(s);
  // Languages without spaces (Chinese, Japanese, Thai): compare character by character.
  return /[぀-ヿ㐀-鿿฀-๿]/.test(n) ? n.replace(/\s/g, "").split("") : n.split(" ").filter(Boolean);
};
function similarity(a, b) {
  const x = tokens(a), y = tokens(b);
  if (!x.length || !y.length) return 0;
  const d = Array.from({ length: x.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= y.length; j++) d[0][j] = j;
  for (let i = 1; i <= x.length; i++)
    for (let j = 1; j <= y.length; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1));
  return Math.max(0, 1 - d[x.length][y.length] / Math.max(x.length, y.length));
}

let last = { transcript: "", score: 0 };
const send = (extra) => chrome.runtime.sendMessage(Object.assign({ type: "speakResult", tab: TAB, req: REQ }, extra), () => window.close());
const status = (msg, cls) => { const s = $("status"); s.textContent = msg; s.className = "status " + (cls || ""); };

$("hear").onclick = () => {
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(TEXT); u.lang = LANG; speechSynthesis.speak(u);
};

const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
async function listen() {
  if (!Rec) { status(t("sp_na"), "err"); setTimeout(() => send({ error: "na" }), 1800); return; }
  try {                                                // ask for the microphone first so Chrome shows its prompt
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((tr) => tr.stop());
  } catch (_) { status(t("sp_denied"), "err"); return; }
  const rec = new Rec();
  rec.lang = LANG; rec.interimResults = true; rec.maxAlternatives = 3; rec.continuous = false;
  let best = "";
  $("start").disabled = true; $("result").hidden = true;
  status(t("sp_listening"), "live");
  rec.onresult = (e) => {
    const res = e.results[e.results.length - 1];
    let alt = res[0].transcript;
    for (let i = 1; i < res.length; i++) if (similarity(res[i].transcript, TEXT) > similarity(alt, TEXT)) alt = res[i].transcript;
    best = alt;
    $("heard").textContent = t("q_you_said", { x: best });
  };
  rec.onerror = (e) => {
    $("start").disabled = false;
    if (e.error === "not-allowed" || e.error === "service-not-allowed") status(t("sp_denied"), "err");
    else if (e.error === "language-not-supported") { status(t("sp_na"), "err"); setTimeout(() => send({ error: "na" }), 1800); }
    else if (e.error === "no-speech") status(t("sp_nothing"), "err");
    else status(e.error, "err");
  };
  rec.onend = () => {
    $("start").disabled = false;
    if (!best) { if ($("status").classList.contains("live")) status(t("sp_nothing"), "err"); return; }
    const score = Math.round(similarity(best, TEXT) * 100);
    last = { transcript: best, score };
    status("");
    $("heard").textContent = t("q_you_said", { x: best });
    $("barFill").style.width = score + "%";
    $("score").textContent = t("q_score", { n: score });
    $("result").hidden = false;
  };
  rec.start();
}
$("start").onclick = listen;
$("again").onclick = listen;
$("use").onclick = () => send(last);
window.addEventListener("beforeunload", () => {
  if (!last.transcript) chrome.runtime.sendMessage({ type: "speakResult", tab: TAB, req: REQ, error: "closed" });
});
