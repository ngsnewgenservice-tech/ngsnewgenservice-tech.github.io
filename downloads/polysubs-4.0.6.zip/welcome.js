/* First-run page: interface language, translation languages, then open a video to try. */
const $ = (id) => document.getElementById(id);
const DEMO_VIDEO = "https://www.youtube.com/watch?v=iG9CE55wbtY";   // TED talk with subtitles in many languages
let ui = psUiLang("");
let picked = [];
const max = PS_LIMITS.free.maxLangs;

function applyI18n() {
  document.documentElement.lang = ui;
  document.documentElement.dir = PS_RTL.includes(ui) ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach((e) => { e.textContent = psT(ui, e.dataset.i18n); });
  $("limitNote").textContent = psT(ui, "w_step2_note", { n: max });
}

function renderLangs() {
  const wrap = $("langs");
  wrap.textContent = "";
  PS_SUB_LANGS.forEach(([code, name]) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip" + (picked.includes(code) ? " on" : "");
    b.textContent = name;
    b.disabled = !picked.includes(code) && picked.length >= max;
    b.onclick = () => {
      picked = picked.includes(code) ? picked.filter((c) => c !== code) : picked.concat(code);
      $("err").hidden = true;
      renderLangs();
    };
    wrap.appendChild(b);
  });
}

PS_UI_LANGS.forEach(([c, n]) => { const o = document.createElement("option"); o.value = c; o.textContent = n; $("uiLang").appendChild(o); });
$("uiLang").onchange = () => { ui = $("uiLang").value; applyI18n(); };

$("go").onclick = () => {
  if (!picked.length) { $("err").hidden = false; return; }
  const langs = picked.map((code, i) => ({ code, size: 22, color: PS_COLORS[i % PS_COLORS.length] }));
  chrome.storage.sync.set({ uiLang: ui, langs, quizLangs: [picked[0]], onboarded: true }, () => {
    $("go").textContent = psT(ui, "w_done");
    setTimeout(() => { location.href = DEMO_VIDEO; }, 600);
  });
};

/* Start from what the background already guessed from the browser language. */
chrome.storage.sync.get({ uiLang: "", langs: [] }, (s) => {
  ui = psUiLang(s.uiLang);
  $("uiLang").value = ui;
  picked = (s.langs || []).map((l) => l.code).filter((c) => PS_SUB_LANGS.some((x) => x[0] === c)).slice(0, max);
  applyI18n();
  renderLangs();
});
